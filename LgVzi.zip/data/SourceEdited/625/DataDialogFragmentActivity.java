package com.my.newproject6;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import java.util.ArrayList;
import java.util.HashMap;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import de.hdodenhof.circleimageview.*;
import android.widget.TextView;
import android.app.Activity;
import android.content.SharedPreferences;
import android.content.Intent;
import android.net.Uri;
import java.util.Timer;
import java.util.TimerTask;
import android.view.View;
import android.graphics.Typeface;
import com.azoft.carousellayoutmanager.*;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.DialogFragment;


public class DataDialogFragmentActivity extends  DialogFragment  { 
	
	private Timer _timer = new Timer();
	
	private String RESIZE = "";
	private String LIST_OF_NAME = "";
	
	private ArrayList<HashMap<String, Object>> HEROADD = new ArrayList<>();
	
	private LinearLayout linear11;
	private LinearLayout linear2;
	private ListView listview1;
	private LinearLayout linear3;
	private CircleImageView circleimageview1;
	private TextView textview1;
	
	private RequestNetwork NET;
	private RequestNetwork.RequestListener _NET_request_listener;
	private SharedPreferences sp;
	private Intent INTENT = new Intent();
	private TimerTask t;
	@NonNull
	@Override
	public View onCreateView(@NonNull LayoutInflater _inflater, @Nullable ViewGroup _container, @Nullable Bundle _savedInstanceState) {
		View _view = _inflater.inflate(R.layout.data_dialog_fragment, _container, false);
		initialize(_savedInstanceState, _view);
		initializeLogic();
		return _view;
	}
	
	private void initialize(Bundle _savedInstanceState, View _view) {
		
		linear11 = (LinearLayout) _view.findViewById(R.id.linear11);
		linear2 = (LinearLayout) _view.findViewById(R.id.linear2);
		listview1 = (ListView) _view.findViewById(R.id.listview1);
		linear3 = (LinearLayout) _view.findViewById(R.id.linear3);
		circleimageview1 = (CircleImageView) _view.findViewById(R.id.circleimageview1);
		textview1 = (TextView) _view.findViewById(R.id.textview1);
		NET = new RequestNetwork((Activity)getContext());
		sp = getContext().getSharedPreferences("sp", Activity.MODE_PRIVATE);
		
		linear11.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				ApplicationUtil.showMessage(getContext(), "hyy");
			}
		});
		
		_NET_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
	}
	
	private void initializeLogic() {
		_ADDGRIDVIEW("ALDOUS", "https://mobile-legends.fandom.com/wiki/Aldous", "");
		_ADDGRIDVIEW("ALPHA", "https://mobile-legends.fandom.com/wiki/Alpha", "");
		_ADDGRIDVIEW("ALUCARD", "https://mobile-legends.fandom.com/wiki/Alucard", "");
		_ADDGRIDVIEW("ARGUS", "https://mobile-legends.fandom.com/wiki/Argus", "");
		_ADDGRIDVIEW("BADANG", "https://mobile-legends.fandom.com/wiki/Badang", "");
		_ADDGRIDVIEW("BALMIND ", "https://mobile-legends.fandom.com/wiki/Balmond", "");
		_ADDGRIDVIEW("BANE", "https://mobile-legends.fandom.com/wiki/Bane", "");
		_ADDGRIDVIEW("BARATS", "https://mobile-legends.fandom.com/wiki/Barats", "");
		_ADDGRIDVIEW("CHOU", "https://mobile-legends.fandom.com/wiki/Chou", "");
		_ADDGRIDVIEW("DYRROTH", "https://mobile-legends.fandom.com/wiki/Dyrroth", "");
		_ADDGRIDVIEW("FREYA", "https://mobile-legends.fandom.com/wiki/Freya", "");
		_ADDGRIDVIEW("GATOT KACA", "https://mobile-legends.fandom.com/wiki/Gatotkaca", "");
		_ADDGRIDVIEW("GUINIVERE", "https://mobile-legends.fandom.com/wiki/Guinevere", "");
		_ADDGRIDVIEW("HILDA", "https://mobile-legends.fandom.com/wiki/Hilda", "");
		_ADDGRIDVIEW("JAWHEAD", "https://mobile-legends.fandom.com/wiki/Jawhead", "");
		_ADDGRIDVIEW("KAJA", "https://mobile-legends.fandom.com/wiki/Kaja", "");
		_ADDGRIDVIEW("KHALEED", "https://mobile-legends.fandom.com/wiki/Khaleed", "");
		_ADDGRIDVIEW("LAPU LAPU", "https://mobile-legends.fandom.com/wiki/Lapu-Lapu", "");
		_ADDGRIDVIEW("LEOMORD", "https://mobile-legends.fandom.com/wiki/Leomord", "");
		_ADDGRIDVIEW("MARTIS", "https://mobile-legends.fandom.com/wiki/Martis", "");
		_ADDGRIDVIEW("MASHA", "https://mobile-legends.fandom.com/wiki/Masha", "");
		_ADDGRIDVIEW("ROGER", "https://mobile-legends.fandom.com/wiki/Roger", "");
		_ADDGRIDVIEW("RUBY", "https://mobile-legends.fandom.com/wiki/Ruby", "");
		_ADDGRIDVIEW("SILVANNA", "https://mobile-legends.fandom.com/wiki/Silvanna", "");
		_ADDGRIDVIEW("SUN", "https://mobile-legends.fandom.com/wiki/Sun", "");
		_ADDGRIDVIEW("THAMUS", "https://mobile-legends.fandom.com/wiki/Thamuz", "");
		_ADDGRIDVIEW("TERIZLA", "https://mobile-legends.fandom.com/wiki/Terizla", "");
		_ADDGRIDVIEW("X BROG", "https://mobile-legends.fandom.com/wiki/X.Borg", "");
		_ADDGRIDVIEW("YU ZHONG", "https://mobile-legends.fandom.com/wiki/Yu_Zhong", "");
		_ADDGRIDVIEW("ZILONG", "https://mobile-legends.fandom.com/wiki/Zilong", "");
	}
	
	@Override
	public void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	public void _ADDGRIDVIEW (final String _NAMA, final String _IMG, final String _URL) {
		{
			HashMap<String, Object> _item = new HashMap<>();
			_item.put("HERO", _NAMA);
			HEROADD.add(_item);
		}
		
		HEROADD.get((int)HEROADD.size() - 1).put("IMG", RESIZE.concat(_IMG));
		listview1.setAdapter(new Listview1Adapter(HEROADD));
		((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
	}
	
	
	public void _OPRIMIZER () {
		RESIZE = "https://img.gs/lclgqccqzr/";
	}
	
	
	public class Listview1Adapter extends BaseAdapter {
		ArrayList<HashMap<String, Object>> _data;
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = (LayoutInflater)getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.listhero, null);
			}
			
			final LinearLayout linear1 = (LinearLayout) _view.findViewById(R.id.linear1);
			final TextView textview3 = (TextView) _view.findViewById(R.id.textview3);
			final ImageView imageview2 = (ImageView) _view.findViewById(R.id.imageview2);
			
			textview3.setText(HEROADD.get((int)_position).get("HERO").toString());
			textview3.setTypeface(Typeface.createFromAsset(getContext().getAssets(),"fonts/googlesans_more_block_20200509131444_more_block_20201231233424_more_block_20210103013840.ttf"), 0);
			Animation animation;
			animation = AnimationUtils.loadAnimation(
			                     getContext(), android.R.anim.slide_in_left
			                 );
			animation.setDuration(300); linear1.startAnimation(animation); animation = null;
			linear1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					LIST_OF_NAME = HEROADD.get((int)_position).get("HERO").toString();
					sp.edit().putString("A", LIST_OF_NAME).commit();
					INTENT.setClass(getContext(), LayoutMenuActivity.class);
					startActivity(INTENT);
				}
			});
			
			return _view;
		}
	}
	
	
}
