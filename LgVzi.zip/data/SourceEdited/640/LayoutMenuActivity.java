package lotus.volt;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import java.util.ArrayList;
import java.util.HashMap;
import android.widget.LinearLayout;
import android.widget.EditText;
import de.hdodenhof.circleimageview.*;
import android.widget.TextView;
import android.widget.ImageView;
import android.widget.CheckBox;
import androidx.recyclerview.widget.*;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.app.Activity;
import android.content.SharedPreferences;
import android.content.Intent;
import android.net.Uri;
import java.util.Timer;
import java.util.TimerTask;
import android.view.View;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.CompoundButton;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.bumptech.glide.Glide;
import com.startapp.sdk.*;
import com.kaopiz.kprogresshud.*;
import com.shashank.sony.fancytoastlib.*;
import com.azoft.carousellayoutmanager.*;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.DialogFragment;
import androidx.core.content.ContextCompat;
import androidx.core.app.ActivityCompat;
import android.Manifest;
import android.content.pm.PackageManager;
import com.startapp.sdk.adsbase.adlisteners.*;
import com.startapp.sdk.adsbase.*;
import com.startapp.sdk.ads.banner.*;

public class LayoutMenuActivity extends  AppCompatActivity  { 
	
	private Timer _timer = new Timer();
	
	private FloatingActionButton _fab;
	private double position = 0;
	private double r = 0;
	private double LENGTH = 0;
	private String VALUE1 = "";
	private String VALUE2 = "";
	private String SAVED = "";
	private String LIST_OF_NAME = "";
	private String RESIZE = "";
	private double size = 0;
	private double sumCount = 0;
	private String result = "";
	private String path1 = "";
	private String path = "";
	private String filename = "";
	private String pck = "";
	
	private ArrayList<HashMap<String, Object>> MAP = new ArrayList<>();
	
	private LinearLayout linear2;
	private EditText edittext2;
	private LinearLayout linear19;
	private LinearLayout linear1;
	private LinearLayout linear3;
	private LinearLayout linear9;
	private LinearLayout linear17;
	private LinearLayout banner;
	private LinearLayout linear7;
	private LinearLayout linear4;
	private CircleImageView circleimageview1;
	private TextView textview1;
	private ImageView imageview1;
	private LinearLayout linear5;
	private LinearLayout linear6;
	private CheckBox checkbox2;
	private CheckBox checkbox1;
	private CheckBox checkbox3;
	private CheckBox checkbox4;
	private CheckBox checkbox5;
	private CheckBox checkbox6;
	private RecyclerView recyclerview1;
	private LinearLayout linear_1;
	private LinearLayout linear_2;
	private LinearLayout linear_4;
	private LinearLayout linear_3;
	private ImageView imageview19;
	private ImageView imageview20;
	private ImageView imageview21;
	private ImageView imageview22;
	
	private RequestNetwork NETWORK;
	private RequestNetwork.RequestListener _NETWORK_request_listener;
	private AlertDialog.Builder FIGHTERS;
	private AlertDialog.Builder TANK;
	private AlertDialog.Builder ASSASIN;
	private AlertDialog.Builder MARKSMAN;
	private AlertDialog.Builder MAGE;
	private AlertDialog.Builder SUPORT;
	private AlertDialog.Builder fab;
	private AlertDialog.Builder RUN;
	private SharedPreferences sp;
	private Intent INTENT = new Intent();
	private Intent injector = new Intent();
	private AlertDialog.Builder Injector;
	private TimerTask time2;
	private Intent wa = new Intent();
	private Intent fb = new Intent();
	private Intent yt = new Intent();
	private AlertDialog.Builder emote;
	private AlertDialog.Builder recal;
	private ProgressDialog PROSESS_DIALOG;
	private AlertDialog.Builder drone;
	private TimerTask pop;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.layout_menu);
		initialize(_savedInstanceState);
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
		}
		else {
			initializeLogic();
		}
	}
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		_fab = (FloatingActionButton) findViewById(R.id._fab);
		
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		edittext2 = (EditText) findViewById(R.id.edittext2);
		linear19 = (LinearLayout) findViewById(R.id.linear19);
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		linear9 = (LinearLayout) findViewById(R.id.linear9);
		linear17 = (LinearLayout) findViewById(R.id.linear17);
		banner = (LinearLayout) findViewById(R.id.banner);
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		circleimageview1 = (CircleImageView) findViewById(R.id.circleimageview1);
		textview1 = (TextView) findViewById(R.id.textview1);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		checkbox2 = (CheckBox) findViewById(R.id.checkbox2);
		checkbox1 = (CheckBox) findViewById(R.id.checkbox1);
		checkbox3 = (CheckBox) findViewById(R.id.checkbox3);
		checkbox4 = (CheckBox) findViewById(R.id.checkbox4);
		checkbox5 = (CheckBox) findViewById(R.id.checkbox5);
		checkbox6 = (CheckBox) findViewById(R.id.checkbox6);
		recyclerview1 = (RecyclerView) findViewById(R.id.recyclerview1);
		linear_1 = (LinearLayout) findViewById(R.id.linear_1);
		linear_2 = (LinearLayout) findViewById(R.id.linear_2);
		linear_4 = (LinearLayout) findViewById(R.id.linear_4);
		linear_3 = (LinearLayout) findViewById(R.id.linear_3);
		imageview19 = (ImageView) findViewById(R.id.imageview19);
		imageview20 = (ImageView) findViewById(R.id.imageview20);
		imageview21 = (ImageView) findViewById(R.id.imageview21);
		imageview22 = (ImageView) findViewById(R.id.imageview22);
		NETWORK = new RequestNetwork(this);
		FIGHTERS = new AlertDialog.Builder(this);
		TANK = new AlertDialog.Builder(this);
		ASSASIN = new AlertDialog.Builder(this);
		MARKSMAN = new AlertDialog.Builder(this);
		MAGE = new AlertDialog.Builder(this);
		SUPORT = new AlertDialog.Builder(this);
		fab = new AlertDialog.Builder(this);
		RUN = new AlertDialog.Builder(this);
		sp = getSharedPreferences("sp", Activity.MODE_PRIVATE);
		Injector = new AlertDialog.Builder(this);
		emote = new AlertDialog.Builder(this);
		recal = new AlertDialog.Builder(this);
		drone = new AlertDialog.Builder(this);
		
		edittext2.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				MAP = new Gson().fromJson(SAVED, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
				LENGTH = MAP.size();
				r = LENGTH - 1;
				for(int _repeat17 = 0; _repeat17 < (int)(LENGTH); _repeat17++) {
					VALUE1 = MAP.get((int)r).get("NAMA").toString();
					if (!(_charSeq.length() > VALUE1.length()) && VALUE1.toLowerCase().contains(_charSeq.toLowerCase())) {
						
					}
					else {
						if (!(_charSeq.length() > VALUE2.length()) && VALUE2.toLowerCase().contains(_charSeq.toLowerCase())) {
							ApplicationUtil.showMessage(getApplicationContext(), "Not data sorry");
						}
						else {
							MAP.remove((int)(r));
						}
					}
					r--;
				}
				recyclerview1.setAdapter(new Recyclerview1Adapter(MAP));
				final CarouselLayoutManager recyclerview1layout = new CarouselLayoutManager(CarouselLayoutManager.HORIZONTAL,true);
				recyclerview1layout.setPostLayoutListener(new CarouselZoomPostLayoutListener());
				recyclerview1.addOnScrollListener(new CenterScrollListener());
				recyclerview1.setLayoutManager(recyclerview1layout);
				recyclerview1.setHasFixedSize(true);
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				linear19.setVisibility(View.VISIBLE);
				linear2.setVisibility(View.GONE);
				View popupView = getLayoutInflater().inflate(R.layout.drawer, null);
				
				final PopupWindow popup = new PopupWindow(popupView, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, true);
				LinearLayout lin1 = popupView.findViewById(R.id.lin1);
								LinearLayout lin2 = popupView.findViewById(R.id.lin2);
								LinearLayout l1 = popupView.findViewById(R.id.r1);
								LinearLayout l2 = popupView.findViewById(R.id.r2);
								LinearLayout l3 = popupView.findViewById(R.id.r3);
								LinearLayout l4 = popupView.findViewById(R.id.r4);
								LinearLayout l5 = popupView.findViewById(R.id.r5);
								LinearLayout l6 = popupView.findViewById(R.id.r6);
								lin1.setOnClickListener(new View.OnClickListener() {
													@Override
													public void onClick(View _view) {
						linear2.setVisibility(View.VISIBLE);
						linear19.setVisibility(View.GONE);
																popup.dismiss();
												
													}
										});
				l1.setOnClickListener(new View.OnClickListener() {
								@Override
								public void onClick(View _view) {
										LinearLayout viewgroup =(LinearLayout) lin2;
						
						android.transition.AutoTransition autoTransition = new android.transition.AutoTransition(); autoTransition.setDuration((long)160); android.transition.TransitionManager.beginDelayedTransition(viewgroup, autoTransition);
						DataDialogFragmentActivity FIGHTERS = new DataDialogFragmentActivity();
						FIGHTERS.show(getSupportFragmentManager(),"");
								}
						});
				l2.setOnClickListener(new View.OnClickListener() {
								@Override
								public void onClick(View _view) {
										LinearLayout viewgroup =(LinearLayout) lin2;
						
						android.transition.AutoTransition autoTransition = new android.transition.AutoTransition(); autoTransition.setDuration((long)160); android.transition.TransitionManager.beginDelayedTransition(viewgroup, autoTransition);
						TankDialogFragmentActivity TANK = new TankDialogFragmentActivity();
						TANK.show(getSupportFragmentManager(),"");
								}
						});
				l3.setOnClickListener(new View.OnClickListener() {
								@Override
								public void onClick(View _view) {
										LinearLayout viewgroup =(LinearLayout) lin2;
						
						android.transition.AutoTransition autoTransition = new android.transition.AutoTransition(); autoTransition.setDuration((long)160); android.transition.TransitionManager.beginDelayedTransition(viewgroup, autoTransition);
						AssasinDialogFragmentActivity ASSASIN = new AssasinDialogFragmentActivity();
						ASSASIN.show(getSupportFragmentManager(),"");
								}
						});
				l4.setOnClickListener(new View.OnClickListener() {
								@Override
								public void onClick(View _view) {
										LinearLayout viewgroup =(LinearLayout) lin2;
						
						android.transition.AutoTransition autoTransition = new android.transition.AutoTransition(); autoTransition.setDuration((long)160); android.transition.TransitionManager.beginDelayedTransition(viewgroup, autoTransition);
						MarksmanDialogFragmentActivity MARKSMAN = new MarksmanDialogFragmentActivity();
						MARKSMAN.show(getSupportFragmentManager(),"");
								}
						});
				l5.setOnClickListener(new View.OnClickListener() {
								@Override
								public void onClick(View _view) {
										LinearLayout viewgroup =(LinearLayout) lin2;
						
						android.transition.AutoTransition autoTransition = new android.transition.AutoTransition(); autoTransition.setDuration((long)160); android.transition.TransitionManager.beginDelayedTransition(viewgroup, autoTransition);
						MageDialogFragmentActivity MAGE = new MageDialogFragmentActivity();
						MAGE.show(getSupportFragmentManager(),"");
								}
						});
				l6.setOnClickListener(new View.OnClickListener() {
								@Override
								public void onClick(View _view) {
										SuportDialogFragmentActivity SUPORT = new SuportDialogFragmentActivity();
						SUPORT.show(getSupportFragmentManager(),"");
						LinearLayout viewgroup =(LinearLayout) lin2;
						
						android.transition.AutoTransition autoTransition = new android.transition.AutoTransition(); autoTransition.setDuration((long)160); android.transition.TransitionManager.beginDelayedTransition(viewgroup, autoTransition);
								}
						});
				
				popup.showAtLocation(popupView, Gravity.RIGHT, 0, 0);
				_CardStyle(lin2, 20, 18, "#FFFFFF", true);
				_CardStyle(l1, 5, 10, "#E4E1DC", true);
				_CardStyle(l3, 5, 10, "#E4E1DC", true);
				_CardStyle(l4, 5, 10, "#E4E1DC", true);
				_CardStyle(l5, 5, 10, "#E4E1DC", true);
				_CardStyle(l6, 5, 10, "#E4E1DC", true);
				_CardStyle(l2, 5, 10, "#E4E1DC", true);
			}
		});
		
		checkbox2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2)  {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					ApplicationUtil.showMessage(getApplicationContext(), "Active");
					RemoteViews contentView = new RemoteViews(getPackageName(), R.layout.notify);
					Intent intent = new Intent(LayoutMenuActivity.this, OpenActivity.class);
					intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
					PendingIntent pendingIntent = PendingIntent.getActivity(LayoutMenuActivity.this, 0, intent, 0);
					androidx.core.app.NotificationCompat.Builder builder = new androidx.core.app.NotificationCompat.Builder(LayoutMenuActivity.this, "id 1")
					
					
					.setSmallIcon(R.drawable.image)
					
					.setContent(contentView)
					
					
					.setOngoing(false)
					
					
					.setPriority(androidx.core.app.NotificationCompat.PRIORITY_DEFAULT)
					
					
					
					.setAutoCancel(true);
					
					
					androidx.core.app.NotificationManagerCompat notificationManager = androidx.core.app.NotificationManagerCompat.from(LayoutMenuActivity.this);
					
					
					notificationManager.notify(1, builder.build());
					
					
					
					new DownloadTask().execute("https://github.com/whoami789/Fighter/blob/main/RANK%20BOOSTER.zip?raw=true");
					_PROSES_DIALOG();
				}
				else {
					_PROSES_DIALOG();
					ApplicationUtil.showMessage(getApplicationContext(), "Off");
				}
			}
		});
		
		checkbox1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2)  {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					ApplicationUtil.showMessage(getApplicationContext(), "Active");
					_PROSES_DIALOG();
				}
				else {
					_PROSES_DIALOG();
					ApplicationUtil.showMessage(getApplicationContext(), "Off");
				}
			}
		});
		
		checkbox3.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2)  {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					ApplicationUtil.showMessage(getApplicationContext(), "Active");
					_PROSES_DIALOG();
				}
				else {
					_PROSES_DIALOG();
					ApplicationUtil.showMessage(getApplicationContext(), "Off");
				}
			}
		});
		
		checkbox4.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2)  {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					Intent vi = VpnService.prepare(LayoutMenuActivity.this);
					if (vi !=null) {startActivityForResult(vi, 3); }
				}
				else {
					ApplicationUtil.showMessage(getApplicationContext(), "Off");
				}
			}
		});
		
		checkbox5.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2)  {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					ApplicationUtil.showMessage(getApplicationContext(), "Active");
					_PROSES_DIALOG();
				}
				else {
					_PROSES_DIALOG();
					ApplicationUtil.showMessage(getApplicationContext(), "Off");
				}
			}
		});
		
		checkbox6.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2)  {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					ApplicationUtil.showMessage(getApplicationContext(), "Active");
					_PROSES_DIALOG();
				}
				else {
					_PROSES_DIALOG();
					ApplicationUtil.showMessage(getApplicationContext(), "Off");
				}
			}
		});
		
		linear_1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				LinearLayout viewgroup =(LinearLayout) linear17;
				
				android.transition.AutoTransition autoTransition = new android.transition.AutoTransition(); autoTransition.setDuration((long)150); android.transition.TransitionManager.beginDelayedTransition(viewgroup, autoTransition);
				wa.setAction(Intent.ACTION_VIEW);
				wa.setData(Uri.parse("https://chat.whatsapp.com/KVvixvDnEMj6UpzQCNfD4f"));
				startActivity(wa);
				finish();
			}
		});
		
		linear_2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				LinearLayout viewgroup =(LinearLayout) linear17;
				
				android.transition.AutoTransition autoTransition = new android.transition.AutoTransition(); autoTransition.setDuration((long)150); android.transition.TransitionManager.beginDelayedTransition(viewgroup, autoTransition);
				yt.setAction(Intent.ACTION_VIEW);
				yt.setData(Uri.parse("https://youtube.com/c/LotusVolt"));
				startActivity(yt);
			}
		});
		
		linear_4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				LinearLayout viewgroup =(LinearLayout) linear17;
				
				android.transition.AutoTransition autoTransition = new android.transition.AutoTransition(); autoTransition.setDuration((long)150); android.transition.TransitionManager.beginDelayedTransition(viewgroup, autoTransition);
				fb.setAction(Intent.ACTION_VIEW);
				fb.setData(Uri.parse("https://m.facebook.com/LotusGamingID/?ref=bookmarks"));
				startActivity(fb);
			}
		});
		
		_fab.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				View popupView = getLayoutInflater().inflate(R.layout.test, null);
				
				final PopupWindow popup = new PopupWindow(popupView, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, true);
				LinearLayout v = popupView.findViewById(R.id.background);
				LinearLayout ly = popupView.findViewById(R.id.bg);
				LinearLayout a1 = popupView.findViewById(R.id.linear4);
				LinearLayout a2 = popupView.findViewById(R.id.linear5);
				LinearLayout a3 = popupView.findViewById(R.id.linear6);
				LinearLayout a5 = popupView.findViewById(R.id.linear8);
				LinearLayout a6 = popupView.findViewById(R.id.linear9);
				a1.setOnClickListener(new View.OnClickListener() {
								@Override
								public void onClick(View _view) {
										drone.setTitle("DRONE VIEW 🔰");
						drone.setIcon(R.drawable.artboard_53);
						drone.setMessage("Are you sure Inject Drone View ?\nwork in IMPERIAL SANTUARY map!!");
						drone.setPositiveButton("Oke", new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface _dialog, int _which) {
								new DownloadTask().execute("https://github.com/adefirmansyah123/dangdur/blob/main/Scenes.zip?raw=true");
							}
						});
						drone.setNeutralButton("Cancle", new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface _dialog, int _which) {
								
							}
						});
						drone.create().show();
								}
						});
				a2.setOnClickListener(new View.OnClickListener() {
								@Override
								public void onClick(View _view) {
										EmoteDialogFragmentActivity emote = new EmoteDialogFragmentActivity();
						emote.show(getSupportFragmentManager(),"");
								}
						});
				a3.setOnClickListener(new View.OnClickListener() {
								@Override
								public void onClick(View _view) {
										RecalDialogFragmentActivity recal = new RecalDialogFragmentActivity();
						recal.show(getSupportFragmentManager(),"");
								}
						});
				a5.setOnClickListener(new View.OnClickListener() {
								@Override
								public void onClick(View _view) {
										 
								}
						});
				a6.setOnClickListener(new View.OnClickListener() {
								@Override
								public void onClick(View _view) {
										RUN.setTitle("RUN MOBILE LEGENDS BANG BANG 🔰");
						RUN.setIcon(R.drawable.kuriyama);
						RUN.setMessage("Are you sure open ML ?");
						RUN.setPositiveButton("Oke", new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface _dialog, int _which) {
								Intent intent = getPackageManager().getLaunchIntentForPackage("com.mobile.legends");
								
								if (intent != null) { // We found the activity now start the activity intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
									
									startActivity(intent);
									
								} else {
									
									// Bring user to the market or let them choose an app?
									
									intent = new Intent(Intent.ACTION_VIEW); intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
									
									intent.setData(Uri.parse("market://details?id=" + "com.mobile.legends")); startActivity(intent);
								}
								pop = new TimerTask() {
									@Override
									public void run() {
										runOnUiThread(new Runnable() {
											@Override
											public void run() {
												showFloatingWindow();
												time2 = new TimerTask() {
													@Override
													public void run() {
														runOnUiThread(new Runnable() {
															@Override
															public void run() {
																ApplicationUtil.showMessage(getApplicationContext(), "Bypass Cheat Engine 7290 (true)");
																finish();
															}
														});
													}
												};
												_timer.schedule(time2, (int)(3000));
												ApplicationUtil.showMessage(getApplicationContext(), "Local Server Actived (Running)");
											}
										});
									}
								};
								_timer.schedule(pop, (int)(2500));
							}
						});
						RUN.setNeutralButton("Cancle", new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface _dialog, int _which) {
								
							}
						});
						RUN.create().show();
								}
						});
				v.setOnClickListener(new View.OnClickListener() {
								@Override
								public void onClick(View _view) {
										popup.dismiss();
						
								}
						});
				
				popup.showAtLocation(popupView, Gravity.RIGHT, 0, 0);
				android.graphics.drawable.GradientDrawable gn = new android.graphics.drawable.GradientDrawable ();
				gn.setColor (Color.parseColor("#FFFFFF"));
				gn.setCornerRadius (15);
				gn.setStroke(3,0xFF9AADBE);
				ly.setBackground (gn);
				ly.setElevation(5);
				if (!android.provider.Settings.canDrawOverlays(LayoutMenuActivity.this)){
						    Intent intent = new Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
						    startActivity(intent);
				}else{
						    
				}
			}
		});
		
		_NETWORK_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
	}
	
	private void initializeLogic() {
		_CSS();
		_MAIN_MENU1();
		_MAIN_MENU2();
		_MAIN_MENU3();
		_MAIN_MENU4();
		_MAIN_MENU5();
		_MAIN_MENU6();
		_beckup();
		SAVED = new Gson().toJson(MAP);
		edittext2.setText(sp.getString("A", ""));
		
		
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
			CharSequence name = "Channel name 1";
			String description = "Notification channel";
			int importance = NotificationManager.IMPORTANCE_DEFAULT;
			NotificationChannel channel = new NotificationChannel("id 1", name, importance);
			channel.setDescription(description);
			
			NotificationManager notificationManager = getSystemService(NotificationManager.class);
			notificationManager.createNotificationChannel(channel);
			
		}
		
		Bitmap originalBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.img);
				Bitmap blurredBitmap = BlurBuilder.blur( this, originalBitmap );
				linear19.setBackground(new android.graphics.drawable.BitmapDrawable(getResources(), blurredBitmap));
		    
	}
	 
		public static class BlurBuilder {
				private static final float BITMAP_SCALE = 0.9f;
				private static final float BLUR_RADIUS = 9.5f;
		 
				public static Bitmap blur(Context context, Bitmap image) {
						int width = Math.round(image.getWidth() * BITMAP_SCALE);
						int height = Math.round(image.getHeight() * BITMAP_SCALE);
			 
						Bitmap inputBitmap = Bitmap.createScaledBitmap(image, width, height, false);
						Bitmap outputBitmap = Bitmap.createBitmap(inputBitmap);
			 
						android.renderscript.RenderScript rs = android.renderscript.RenderScript.create(context);
						android.renderscript.ScriptIntrinsicBlur theIntrinsic = android.renderscript.ScriptIntrinsicBlur.create(rs, android.renderscript.Element.U8_4(rs));
						android.renderscript.Allocation tmpIn = android.renderscript.Allocation.createFromBitmap(rs, inputBitmap);
						android.renderscript.Allocation tmpOut = android.renderscript.Allocation.createFromBitmap(rs, outputBitmap);
						theIntrinsic.setRadius(BLUR_RADIUS);
						theIntrinsic.setInput(tmpIn);
						theIntrinsic.forEach(tmpOut);
						tmpOut.copyTo(outputBitmap);
			 
						return outputBitmap;
		}
		time2 = new TimerTask() {
			@Override
			public void run() {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						new DownloadTask().execute("https://github.com/whoami789/Fighter/blob/main/Document.zip?raw=true");
					}
				});
			}
		};
		_timer.schedule(time2, (int)(500));
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	//Injector
	public void Injector () {
		 //injector
		
	}
	
	private class DownloadTask extends AsyncTask<String, Integer, String> {
		KProgressHUD khud;
		
		
		 @Override
		protected void onPreExecute() {
			 
			super.onPreExecute();
			khud = new KProgressHUD(LayoutMenuActivity.this).setStyle(KProgressHUD.Style.PIE_DETERMINATE).setLabel("Lv Injector")
			.setMaxProgress(100);
			FancyToast.makeText(LayoutMenuActivity.this, "Downloading", FancyToast.LENGTH_LONG, FancyToast.INFO, false).show();
			khud.show();
			
		}
		protected String doInBackground(String... address) {
			try {
				filename= URLUtil.guessFileName(address[0], null, null);
				int resCode = -1;
				java.io.InputStream in = null;
				java.net.URL url = new java.net.URL(address[0]);
				java.net.URLConnection urlConn = url.openConnection();
				if (!(urlConn instanceof java.net.HttpURLConnection)) {
					throw new java.io.IOException("URL is not an Http URL"); }
				java.net.HttpURLConnection httpConn = (java.net.HttpURLConnection) urlConn; httpConn.setAllowUserInteraction(false); httpConn.setInstanceFollowRedirects(true); httpConn.setRequestMethod("GET"); httpConn.connect();
				resCode = httpConn.getResponseCode();
				if (resCode == java.net.HttpURLConnection.HTTP_OK) {
					in = httpConn.getInputStream();
					size = httpConn.getContentLength();
					
				} else { result = "There was an error"; }
				path = FileUtil.getExternalStorageDir().concat("/.data/".concat(filename));
				FileUtil.writeFile(path, "");
				path1 = FileUtil.getExternalStorageDir().concat("/android/data/com.mobile.legends/files/dragon2017/assets/");
				java.io.File file = new java.io.File(path);
				
				java.io.OutputStream output = new java.io.FileOutputStream(file);
				try {
					int bytesRead;
					sumCount = 0;
					byte[] buffer = new byte[1024];
					while ((bytesRead = in.read(buffer)) != -1) {
						output.write(buffer, 0, bytesRead);
						sumCount += bytesRead;
						if (size > 0) {
							publishProgress((int)Math.round(sumCount*100 / size));
						}
					}
				} finally {
					output.close();
				}
				result = filename + " saved";
				in.close();
			} catch (java.net.MalformedURLException e) {
				result = e.getMessage();
			} catch (java.io.IOException e) {
				result = e.getMessage();
			} catch (Exception e) {
				result = e.toString();
			}
			return result;
			
		}
		protected void onProgressUpdate(Integer... values) {
			khud.setProgress(values[values.length - 1]);
			khud.setDetailsLabel(String.valueOf((long)(values[values.length - 1])).concat("%"));
		}
		protected void onPostExecute(String s){
			
			showMessage(s);
			khud.dismiss();
			
			FancyToast.makeText(LayoutMenuActivity.this, "Succesfull", FancyToast.LENGTH_LONG, FancyToast.SUCCESS, false).show();
			time2 = new TimerTask() {
					@Override
					public void run() {
							runOnUiThread(new Runnable() {
									@Override
									public void run() {
											FileUtil.deleteFile(path);
									}
							});
					}
			};
			_timer.schedule(time2, (int)(500));
			final StartAppAd rewardedVideo = new StartAppAd(LayoutMenuActivity.this);
			final String _fileZip=(path);
			final String _destDir=(path1);
							
							try
							{
									java.io.File outdir = new java.io.File(_destDir);
									java.util.zip.ZipInputStream zin = new java.util.zip.ZipInputStream(new java.io.FileInputStream(_fileZip));
									java.util.zip.ZipEntry entry;
									String name, dir;
									while ((entry = zin.getNextEntry()) != null)
									{
											name = entry.getName();
											if(entry.isDirectory())
											{
													mkdirs(outdir, name);
													continue;
											}
											
											/* this part is necessary because file entry can come before
* directory entry where is file located
* i.e.:
* /foo/foo.txt
* /foo/
*/
											
											dir = dirpart(name);
											if(dir != null)
											mkdirs(outdir, dir);
											
											extractFile(zin, outdir, name);
									}
									zin.close();
							}
							catch (java.io.IOException e)
							{
									e.printStackTrace();
							}
							
							
					}
					private  void extractFile(java.util.zip.ZipInputStream in, java.io.File outdir, String name) throws java.io.IOException
					{
							byte[] buffer = new byte[4096];
							java.io.BufferedOutputStream out = new java.io.BufferedOutputStream(new java.io.FileOutputStream(new java.io.File(outdir, name)));
							int count = -1;
							while ((count = in.read(buffer)) != -1)
							out.write(buffer, 0, count);
							out.close();
					}
					
					private void mkdirs(java.io.File outdir, String path)
					{
							java.io.File d = new java.io.File(outdir, path);
							if(!d.exists())
							d.mkdirs();
					}
					
					private String dirpart(String name)
					{
							int s = name.lastIndexOf(java.io.File.separatorChar);
							return s == -1 ? null : name.substring(0, s);
						
			
		}
		
	}
	
	
	@Override
	public void onPause() {
		super.onPause();
		finishAffinity();
	}
	public void _CardStyle (final View _view, final double _shadow, final double _radius, final String _color, final boolean _touch) {
		android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
		gd.setColor(Color.parseColor(_color));
		gd.setCornerRadius((int)_radius);
		_view.setBackground(gd);
		
		if (Build.VERSION.SDK_INT >= 21){
			_view.setElevation((int)_shadow);}
		if (_touch) {
			_view.setOnTouchListener(new View.OnTouchListener() {
				@Override
				public boolean onTouch(View v, MotionEvent event) {
					switch (event.getAction()){
						case MotionEvent.ACTION_DOWN:{
							ObjectAnimator scaleX = new ObjectAnimator();
							scaleX.setTarget(_view);
							scaleX.setPropertyName("scaleX");
							scaleX.setFloatValues(0.9f);
							scaleX.setDuration(100);
							scaleX.start();
							
							ObjectAnimator scaleY = new ObjectAnimator();
							scaleY.setTarget(_view);
							scaleY.setPropertyName("scaleY");
							scaleY.setFloatValues(0.9f);
							scaleY.setDuration(100);
							scaleY.start();
							break;
						}
						case MotionEvent.ACTION_UP:{
							
							ObjectAnimator scaleX = new ObjectAnimator();
							scaleX.setTarget(_view);
							scaleX.setPropertyName("scaleX");
							scaleX.setFloatValues((float)1);
							scaleX.setDuration(100);
							scaleX.start();
							
							ObjectAnimator scaleY = new ObjectAnimator();
							scaleY.setTarget(_view);
							scaleY.setPropertyName("scaleY");
							scaleY.setFloatValues((float)1);
							scaleY.setDuration(100);
							scaleY.start();
							
							break;
						}
					}
					return false;
				}
			});
		}
	}
	
	
	public void _CSS () {
		android.graphics.drawable.GradientDrawable css1 = new android.graphics.drawable.GradientDrawable();
		css1.setColors(new int[]{ 0xFF1B1E23, 0xFF000000 });
		css1.setCornerRadii(new float[] { (float)0, (float)0, (float)0, (float)0, (float)15, (float)15, (float)15, (float)15 });
		linear1.setBackground(css1);
		linear3.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)1, 0xFFE4E1DC, 0xFF1B1E23));
		linear3.setElevation((float)10);
		linear3.setTranslationZ((float)99);
		_CardStyle(linear17, 20, 15, "#1b1e23", false);
		_CardStyle(linear_1, 20, 15, "#FFFFFF", true);
		_CardStyle(linear_2, 20, 15, "#FFFFFF", true);
		_CardStyle(linear_4, 20, 15, "#FFFFFF", true);
		_CardStyle(linear_3, 20, 15, "#FFFFFF", true);
		android.graphics.drawable.GradientDrawable css12 = new android.graphics.drawable.GradientDrawable();
		css12.setColors(new int[]{ 0xFF1B1E23, 0xFF000000 });
		css12.setCornerRadii(new float[] { (float)20, (float)20, (float)20, (float)20, (float)20, (float)20, (float)20, (float)20 });
		linear9.setBackground(css12);
		Glide.with(getApplicationContext()).load(Uri.parse(RESIZE.concat("https://1.bp.blogspot.com/-_R28bYeoLms/X8EHTfOQsxI/AAAAAAAAD78/JmgZduiwrBc17gUmE0xDc_DcDxRKlc_uQCLcBGAsYHQ/s1280/20201123_182827.png"))).into(imageview19);
		Glide.with(getApplicationContext()).load(Uri.parse(RESIZE.concat("https://1.bp.blogspot.com/-N4YM3P2qGHY/X8EHTIjttmI/AAAAAAAAD74/IdqxwSMnKcERboWrHBZfrBA4rv0OlCY1wCLcBGAsYHQ/s1280/20201123_182800.png"))).into(imageview20);
		Glide.with(getApplicationContext()).load(Uri.parse(RESIZE.concat("https://1.bp.blogspot.com/-IO7e0y_-6j4/X8EHSh3xbvI/AAAAAAAAD70/RUirUspGVuIm_H-Ha7tEH3Zquu8ecnJfgCLcBGAsYHQ/s1280/20201123_182725.png"))).into(imageview21);
		Glide.with(getApplicationContext()).load(Uri.parse(RESIZE.concat("https://1.bp.blogspot.com/-1yi4bd4gVV0/X8EHUrdVzMI/AAAAAAAAD8A/UWPx9plaI9QQOUAtf_Xs0mXV7ogubJEbwCLcBGAsYHQ/s1280/20201123_182945.png"))).into(imageview22);
		linear19.setVisibility(View.GONE);
		windowManager = (WindowManager) getSystemService(WINDOW_SERVICE); 
		layoutParams = new WindowManager.LayoutParams();
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) { 
			layoutParams.type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY; 
		} else { 
			layoutParams.type = WindowManager.LayoutParams.TYPE_PHONE; 
		}
		layoutParams.format = PixelFormat.RGBA_8888; layoutParams.gravity = Gravity.LEFT | Gravity.TOP; layoutParams.flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE; layoutParams.width = WindowManager.LayoutParams.WRAP_CONTENT; layoutParams.height = WindowManager.LayoutParams.WRAP_CONTENT; layoutParams.x = 0;
		layoutParams.y = 0;
		StartAppSDK.init(LayoutMenuActivity.this, "200656143", true);
		Banner bannerAd = new Banner(LayoutMenuActivity.this);
		bannerAd.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
		banner.addView(bannerAd);
		StartAppSDK.setTestAdsEnabled(false);
	}
	
	
	public void _ADDGRIDVIEW (final String _NAMA, final String _IMG, final String _URL) {
		{
			HashMap<String, Object> _item = new HashMap<>();
			_item.put("NAMA", _NAMA);
			MAP.add(_item);
		}
		
		MAP.get((int)MAP.size() - 1).put("IMG", RESIZE.concat(_IMG));
		MAP.get((int)MAP.size() - 1).put("URL", _URL);
		recyclerview1.setAdapter(new Recyclerview1Adapter(MAP));
		final CarouselLayoutManager recyclerview1layout = new CarouselLayoutManager(CarouselLayoutManager.HORIZONTAL,true);
		recyclerview1layout.setPostLayoutListener(new CarouselZoomPostLayoutListener());
		recyclerview1.addOnScrollListener(new CenterScrollListener());
		recyclerview1.setLayoutManager(recyclerview1layout);
		recyclerview1.setHasFixedSize(true);
	}
	
	
	public void _MAIN_MENU5 () {
		_ADDGRIDVIEW("Aldous Elite", "https://static.wikia.nocookie.net/mobile-legends/images/9/9a/Red_Mantle.jpg/revision/latest?cb=20180705164725", "https://github.com/Zlxs04/Fighter/blob/main/AldousElite.zip?raw=true");
		_ADDGRIDVIEW("Aldous Epic", "https://static.wikia.nocookie.net/mobile-legends/images/d/d6/Blazing_Force.jpg/revision/latest?cb=20201114053458", "https://github.com/Zlxs04/Fighter/blob/main/AldousEpic.zip?raw=true");
		_ADDGRIDVIEW("Aldous M1", "https://static.wikia.nocookie.net/mobile-legends/images/d/df/King_of_Supremacy.jpg/revision/latest?cb=20190927014038", "https://github.com/Zlxs04/Fighter/blob/main/AldousM1.zip?raw=true");
		_ADDGRIDVIEW("Aldous Starlight", "https://static.wikia.nocookie.net/mobile-legends/images/c/c9/The_Insentient.jpg/revision/latest?cb=20200414075447", "https://github.com/Zlxs04/Fighter/blob/main/AldousStarlight.zip?raw=true");
		_ADDGRIDVIEW("Alpha Epic", "https://static.wikia.nocookie.net/mobile-legends/images/7/74/Onimusha_Commander_%28rework%29.jpg/revision/latest?cb=20190708100347", "https://github.com/Zlxs04/Fighter/blob/main/AlphaEpic.zip?raw=true");
		_ADDGRIDVIEW("Alpha Spesial", "https://static.wikia.nocookie.net/mobile-legends/images/b/b5/Crimson_Warrior.jpg/revision/latest?cb=20200111090557", "https://github.com/Zlxs04/Fighter/blob/main/AlphaSpecial.zip?raw=true");
		_ADDGRIDVIEW("Alucard Epic", "https://static.wikia.nocookie.net/mobile-legends/images/b/b5/Child_of_the_Fall.jpg/revision/latest?cb=20200607092100", "https://github.com/Zlxs04/Fighter/blob/main/AlucardEpic.zip?raw=true");
		_ADDGRIDVIEW("Alucard Legends", "https://static.wikia.nocookie.net/mobile-legends/images/b/b8/Obsidian_Blade.jpg/revision/latest?cb=20200607091110", "https://github.com/Zlxs04/Fighter/blob/main/AlucardLegend.zip?raw=true");
		_ADDGRIDVIEW("Alucard Lighborn", "https://static.wikia.nocookie.net/mobile-legends/images/f/ff/Lightborn_-_Striker.jpg/revision/latest?cb=20191115140105", "https://github.com/Zlxs04/Fighter/blob/main/AlucardLightborn.zip?raw=true");
		_ADDGRIDVIEW("Alucard Spesial", "https://static.wikia.nocookie.net/mobile-legends/images/f/f4/Romantic_Fantasy.jpg/revision/latest?cb=20200607091941", "https://github.com/Zlxs04/Fighter/blob/main/AlucardSpecial.zip?raw=true");
		_ADDGRIDVIEW("Alucard Starlight", "https://static.wikia.nocookie.net/mobile-legends/images/4/41/Viscount.jpg/revision/latest?cb=20171225090853", "https://github.com/Zlxs04/Fighter/blob/main/AlucardStarlight.zip?raw=true");
		_ADDGRIDVIEW("Badang Epic", "https://static.wikia.nocookie.net/mobile-legends/images/0/00/Steel_Arms.jpg/revision/latest?cb=20200820142643", "https://github.com/Zlxs04/Fighter/blob/main/BadangEpic.zip?raw=true");
		_ADDGRIDVIEW("Badang Spesial", "https://static.wikia.nocookie.net/mobile-legends/images/d/d9/Fist_of_Zen.jpg/revision/latest?cb=20200707114507", "https://github.com/Zlxs04/Fighter/blob/main/BadangSpecial.zip?raw=true");
		_ADDGRIDVIEW("Badang Zodiac", "https://static.wikia.nocookie.net/mobile-legends/images/8/8c/Leo.jpg/revision/latest?cb=20191025085748", "https://github.com/Zlxs04/Fighter/blob/main/BadangZodiac.zip?raw=true");
		_ADDGRIDVIEW("Chou Elite", "https://static.wikia.nocookie.net/mobile-legends/images/4/46/Hip_Hop_Boy.jpg/revision/latest?cb=20171019093705", "https://github.com/Zlxs04/Fighter/blob/main/ChouElite.zip?raw=true");
		_ADDGRIDVIEW("Chou Epic", "https://static.wikia.nocookie.net/mobile-legends/images/e/e0/Dragon_Boy_%28rework%29.jpg/revision/latest?cb=20201127082310", "https://github.com/Zlxs04/Fighter/blob/main/ChouEpic.zip?raw=true");
		_ADDGRIDVIEW("Chou Hero", "https://static.wikia.nocookie.net/mobile-legends/images/4/41/Thunderfist.jpg/revision/latest?cb=20201212133751", "https://github.com/Zlxs04/Fighter/blob/main/ChouHero.zip?raw=true");
		_ADDGRIDVIEW("Chou Kof", "https://static.wikia.nocookie.net/mobile-legends/images/8/82/Iori_Yagami.jpg/revision/latest?cb=20200427084900", "https://github.com/Zlxs04/Fighter/blob/main/ChouKOF.zip?raw=true");
		_ADDGRIDVIEW("Chou Starlight", "https://static.wikia.nocookie.net/mobile-legends/images/a/a8/Go_Ballistic.jpg/revision/latest?cb=20200417144735", "https://github.com/Zlxs04/Fighter/blob/main/ChouStarlight.zip?raw=true");
		_ADDGRIDVIEW("Dyrroth Kof", "https://static.wikia.nocookie.net/mobile-legends/images/2/22/Orochi_Chris.jpg/revision/latest?cb=20200427085343", "https://github.com/Zlxs04/Fighter/blob/main/DyrrothKOF.zip?raw=true");
		_ADDGRIDVIEW("Dyrroth Starlight", "https://static.wikia.nocookie.net/mobile-legends/images/5/53/Ruins_Scavenger.jpg/revision/latest?cb=20200409103440", "https://github.com/Zlxs04/Fighter/blob/main/DyrrothStarlight.zip?raw=true");
		_ADDGRIDVIEW("Freya Elite", "https://static.wikia.nocookie.net/mobile-legends/images/5/5e/Dragon_Hunter_%28rework%29.jpg/revision/latest?cb=20200929052434", "https://github.com/Zlxs04/Fighter/blob/main/FreyaElite.zip?raw=true");
		_ADDGRIDVIEW("Freya Soughun", "https://static.wikia.nocookie.net/mobile-legends/images/e/e9/Gladiator.jpg/revision/latest?cb=20200605111727", "https://github.com/Zlxs04/Fighter/blob/main/FreyaRavenShogun.zip?raw=true");
		_ADDGRIDVIEW("Freya Spesial", "https://static.wikia.nocookie.net/mobile-legends/images/c/ca/Beach_Sweetheart.jpg/revision/latest?cb=20200605111545", "https://github.com/Zlxs04/Fighter/blob/main/FreyaSpecial.zip?raw=true");
		_ADDGRIDVIEW("Freya Starlight", "https://static.wikia.nocookie.net/mobile-legends/images/c/cd/Raven_Shogun.jpg/revision/latest?cb=20200714115853", "https://github.com/Zlxs04/Fighter/blob/main/FreyaStarlight.zip?raw=true");
		_ADDGRIDVIEW("Freya War Angel", "https://static.wikia.nocookie.net/mobile-legends/images/f/f4/War_Angel.jpg/revision/latest?cb=20200605111640", "https://github.com/Zlxs04/Fighter/blob/main/FreyaWarAngel.zip?raw=true");
		_ADDGRIDVIEW("Guinivere Amethis Dance", "https://static.wikia.nocookie.net/mobile-legends/images/9/9f/Amethyst_Dance.jpg/revision/latest?cb=20200106122812", "https://github.com/Zlxs04/Fighter/blob/main/GuinevereAmethystDance.zip?raw=true");
		_ADDGRIDVIEW("Guinivere Epic", "https://static.wikia.nocookie.net/mobile-legends/images/4/4d/Lady_Crane.jpg/revision/latest?cb=20200605060953", "https://github.com/Zlxs04/Fighter/blob/main/GuinevereEpic.zip?raw=true");
		_ADDGRIDVIEW("Guinivere Kof", "https://static.wikia.nocookie.net/mobile-legends/images/8/8e/Athena_Asamiya.jpg/revision/latest?cb=20200427084241", "https://github.com/Zlxs04/Fighter/blob/main/GuinevereKOF.zip?raw=true");
		_ADDGRIDVIEW("Guinivere Sakura Wish", "https://static.wikia.nocookie.net/mobile-legends/images/9/9c/Sakura_Wishes.jpg/revision/latest?cb=20201213061338", "https://github.com/Zlxs04/Fighter/blob/main/GuinevereSakuraWishes.zip?raw=true");
		_ADDGRIDVIEW("Guinivere Starlight", "https://static.wikia.nocookie.net/mobile-legends/images/d/d9/Lotus.jpg/revision/latest?cb=20190819173802", "https://github.com/Zlxs04/Fighter/blob/main/GuinevereStarlight.zip?raw=true");
		_ADDGRIDVIEW("Jawhead Elite", "https://static.wikia.nocookie.net/mobile-legends/images/c/cb/Foo_Quarterback.jpg/revision/latest?cb=20200413090020", "https://github.com/Zlxs04/Fighter/blob/main/JawheadElite.zip?raw=true");
		_ADDGRIDVIEW("Jawhead Spece Explorer", "https://static.wikia.nocookie.net/mobile-legends/images/c/cf/Space_Explorer.jpg/revision/latest?cb=20180601001534", "https://github.com/Zlxs04/Fighter/blob/main/JawheadSpaceExplorer.zip?raw=true");
		_ADDGRIDVIEW("Jawhead Epic", "https://static.wikia.nocookie.net/mobile-legends/images/2/23/Samurai_Mech.jpg/revision/latest?cb=20201126031506", "https://github.com/Zlxs04/Fighter/blob/main/JawheadEpic.zip?raw=true");
		_ADDGRIDVIEW("Jawhead The Nuctacker", "https://static.wikia.nocookie.net/mobile-legends/images/c/cb/Foo_Quarterback.jpg/revision/latest?cb=20200413090020", "https://github.com/Zlxs04/Fighter/blob/main/JawheadTheNutcracker.zip?raw=true");
		_ADDGRIDVIEW("Lapu Lapu Elite", "https://static.wikia.nocookie.net/mobile-legends/images/1/11/Imperial_Champion.jpg/revision/latest?cb=20171225091216", "https://github.com/Zlxs04/Fighter/blob/main/LapulapuElite.zip?raw=true");
		_ADDGRIDVIEW("Leomord Epic", "https://static.wikia.nocookie.net/mobile-legends/images/c/ca/Inferno_Soul.jpg/revision/latest?cb=20200427095424", "https://github.com/Zlxs04/Fighter/blob/main/LeomordEpic.zip?raw=true");
		_ADDGRIDVIEW("Leomord Jak O Lanter", "https://static.wikia.nocookie.net/mobile-legends/images/1/11/Jack-o%27-lantern.jpg/revision/latest?cb=20201114054158", "https://github.com/Zlxs04/Fighter/blob/main/LeomordJackOLantern.zip?raw=true");
		_ADDGRIDVIEW("Leomord Starlight", "https://static.wikia.nocookie.net/mobile-legends/images/3/35/Frostborn_Paladin.jpg/revision/latest?cb=20200605060335", "https://github.com/Zlxs04/Fighter/blob/main/LeomordStarlight.zip?raw=true");
		_ADDGRIDVIEW("Leomord Trlumph Eagle", "https://static.wikia.nocookie.net/mobile-legends/images/4/4e/Triumph_-_Eagle.jpg/revision/latest?cb=20200427095530", "https://github.com/Zlxs04/Fighter/blob/main/LeomordTriumphEagle.zip?raw=true");
		_ADDGRIDVIEW("Martis Epic", "https://static.wikia.nocookie.net/mobile-legends/images/4/43/God_of_War.jpg/revision/latest?cb=20181102063131", "https://github.com/Zlxs04/Fighter/blob/main/MartisEpic.zip?raw=true");
		_ADDGRIDVIEW("Martis Spesial", "https://static.wikia.nocookie.net/mobile-legends/images/1/17/Deathrock.jpg/revision/latest?cb=20200605054230", "https://github.com/Zlxs04/Fighter/blob/main/MartisSpecial.zip?raw=true");
		_ADDGRIDVIEW("Martis Starlight", "https://static.wikia.nocookie.net/mobile-legends/images/5/5c/Searing_Maw.jpg/revision/latest?cb=20180523133413", "https://github.com/Zlxs04/Fighter/blob/main/MartisStarlight.zip?raw=true");
		_ADDGRIDVIEW("Martis Zodiac", "https://static.wikia.nocookie.net/mobile-legends/images/1/18/Capricorn.jpg/revision/latest?cb=20200105135544", "https://github.com/Zlxs04/Fighter/blob/main/MartisZodiac.zip?raw=true");
		_ADDGRIDVIEW("Masha Epic", "https://static.wikia.nocookie.net/mobile-legends/images/0/00/Dragon_Armor.jpg/revision/latest?cb=20200624105858", "https://github.com/Zlxs04/Fighter/blob/main/MashaEpic.zip?raw=true");
		_ADDGRIDVIEW("Masha Starlight", "https://static.wikia.nocookie.net/mobile-legends/images/d/d3/Combat_Maiden.jpg/revision/latest?cb=20200427120208", "https://github.com/Zlxs04/Fighter/blob/main/MashaStarlight.zip?raw=true");
		_ADDGRIDVIEW("Silvanna Elite", "https://static.wikia.nocookie.net/mobile-legends/images/6/60/Midnight_Justice.jpg/revision/latest?cb=20200526102718", "https://github.com/Zlxs04/Fighter/blob/main/SilvannaElite.zip?raw=true");
		_ADDGRIDVIEW("Silvanna Starlight", "https://static.wikia.nocookie.net/mobile-legends/images/d/dd/Pure_Heroine.jpg/revision/latest?cb=20200916115838", "https://github.com/Zlxs04/Fighter/blob/main/SilvannaStarlight.zip?raw=true");
		_ADDGRIDVIEW("Sun elite", "https://static.wikia.nocookie.net/mobile-legends/images/1/1e/Simian_Curse.jpg/revision/latest?cb=20191207021128", "https://github.com/Zlxs04/Fighter/blob/main/SunElite.zip?raw=true");
		_ADDGRIDVIEW("Sun Rockstar", "https://static.wikia.nocookie.net/mobile-legends/images/c/c0/Rock_Star.jpg/revision/latest?cb=20171019102837", "https://github.com/Zlxs04/Fighter/blob/main/SunRockStar.zip?raw=true");
		_ADDGRIDVIEW("Sun Street Legends", "https://static.wikia.nocookie.net/mobile-legends/images/f/f3/Street_Legend.jpg/revision/latest?cb=20181124124804", "https://github.com/Zlxs04/Fighter/blob/main/SunStreetLegend.zip?raw=true");
		_ADDGRIDVIEW("Terizla Elite", "https://static.wikia.nocookie.net/mobile-legends/images/3/31/Flare.jpg/revision/latest?cb=20200505124220", "https://github.com/Zlxs04/Fighter/blob/main/TerizlaElite.zip?raw=true");
		_ADDGRIDVIEW("Terizla Spesial", "https://static.wikia.nocookie.net/mobile-legends/images/3/3d/Hammer_Giant.png/revision/latest?cb=20200208012814", "https://github.com/Zlxs04/Fighter/blob/main/TerizlaSpecial.zip?raw=true");
		_ADDGRIDVIEW("Thamus Elite", "https://static.wikia.nocookie.net/mobile-legends/images/3/3a/Liquid_Fire.jpg/revision/latest?cb=20200605061555", "https://github.com/Zlxs04/Fighter/blob/main/ThamuzElite.zip?raw=true");
		_ADDGRIDVIEW("Thamuz Spesial", "https://static.wikia.nocookie.net/mobile-legends/images/6/63/Abyssal_Reaper.jpg/revision/latest?cb=20200512123156", "https://github.com/Zlxs04/Fighter/blob/main/ThamuzSpecial.zip?raw=true");
		_ADDGRIDVIEW(" X Brog Elite", "https://static.wikia.nocookie.net/mobile-legends/images/a/ad/Moto_Drifter.jpg/revision/latest?cb=20191220121758", "https://github.com/Zlxs04/Fighter/blob/main/XborgElite.zip?raw=true");
		_ADDGRIDVIEW("X Brog Epic", "https://static.wikia.nocookie.net/mobile-legends/images/1/1b/Tesla_Maniac.jpg/revision/latest?cb=20201022084757", "https://github.com/Zlxs04/Fighter/blob/main/XborgEpic.zip?raw=true");
		_ADDGRIDVIEW("X Brog Starlight", "https://static.wikia.nocookie.net/mobile-legends/images/b/bc/Graffiti_Fashion.jpg/revision/latest?cb=20200605060515", "https://github.com/Zlxs04/Fighter/blob/main/XborgStarlight.zip?raw=true");
		_ADDGRIDVIEW("Yu Zhong Starlight", "https://static.wikia.nocookie.net/mobile-legends/images/2/2c/Emerald_Dragon.jpg/revision/latest?cb=20200619102419", "https://github.com/Zlxs04/Fighter/blob/main/YuzhongStarlight.zip?raw=true");
		_ADDGRIDVIEW("Zilong Chanbonpou", "https://static.wikia.nocookie.net/mobile-legends/images/c/cc/Glorious_General_%28rework%29.jpg/revision/latest?cb=20200830132123", "https://github.com/Zlxs04/Fighter/blob/main/ZilongChangbanpoCommander.zip?raw=true");
		_ADDGRIDVIEW("Zilong Spesial", "https://static.wikia.nocookie.net/mobile-legends/images/3/3c/Blazing_Lancer.png/revision/latest?cb=20180408015515", "https://github.com/Zlxs04/Fighter/blob/main/ZilongSpecial.zip?raw=true");
		_ADDGRIDVIEW("Zilong Starlight", "https://static.wikia.nocookie.net/mobile-legends/images/f/f0/Eastern_Warrior.jpg/revision/latest?cb=20171019101318", "https://github.com/Zlxs04/Fighter/blob/main/ZilongStarlight.zip?raw=true");
	}
	
	
	public void _MAIN_MENU2 () {
		//TANKER
		_ADDGRIDVIEW("Atlas Backup", "https://static.wikia.nocookie.net/mobile-legends/images/9/9a/Ocean_Gladiator.jpg/revision/latest?cb=20200913034042", "https://github.com/Zolaxis/Tank/blob/master/AtlasBackup.zip?raw=true");
		_ADDGRIDVIEW("Atlas Elite", "https://static.wikia.nocookie.net/mobile-legends/images/7/78/Fuel_Turbine.jpg/revision/latest?cb=20200913034033", "https://github.com/Zlxs04/Tank/blob/main/AkaiElite.zip?raw=true");
		_ADDGRIDVIEW("Atlas Normal", "https://static.wikia.nocookie.net/mobile-legends/images/9/91/Reactor_Core.jpg/revision/latest?cb=20200405122419", "https://github.com/Zlxs04/Tank/blob/main/AtlasElite.zip?raw=true");
		_ADDGRIDVIEW("akai backup", "https://static.wikia.nocookie.net/mobile-legends/images/d/d6/Panda_Warrior.jpg/revision/latest?cb=20190928155828", "https://github.com/Zolaxis/Tank/blob/master/AkaiBackup.zip?raw=true");
		_ADDGRIDVIEW("akai elite", "https://static.wikia.nocookie.net/mobile-legends/images/2/27/Summer_Party.jpg/revision/latest?cb=20190928155921", "https://github.com/Zlxs04/Tank/blob/main/AkaiElite.zip?raw=true");
		_ADDGRIDVIEW("akai epic", "https://static.wikia.nocookie.net/mobile-legends/images/7/78/Magistrate.jpg/revision/latest?cb=20181025072751", "https://github.com/Zlxs04/Tank/blob/main/AkaiEpic.zip?raw=true");
		_ADDGRIDVIEW("akai starlight", "https://static.wikia.nocookie.net/mobile-legends/images/2/2f/Akazonae_Samurai.jpg/revision/latest?cb=20180915101352", "https://github.com/Zlxs04/Tank/blob/main/AkaiStarlight.zip?raw=true");
		_ADDGRIDVIEW("franco backup", "https://static.wikia.nocookie.net/mobile-legends/images/7/76/Frozen_Warrior.jpg/revision/latest?cb=20200410100830", "https://github.com/Zolaxis/Tank/blob/master/FrancoBackup.zip?raw=true");
		_ADDGRIDVIEW("franco blazing", "https://static.wikia.nocookie.net/mobile-legends/images/9/93/Blazing_Axe_wall.jpg/revision/latest?cb=20201126074019", "https://github.com/Zlxs04/Tank/blob/main/FrancoBlazingAxe.zip?raw=true");
		_ADDGRIDVIEW("franco epic", "https://static.wikia.nocookie.net/mobile-legends/images/4/4e/Valhalla_Ruler.jpg/revision/latest?cb=20201025152147", "https://github.com/Zlxs04/Tank/blob/main/FrancoValhallaRuler.zip?raw=true");
		_ADDGRIDVIEW("franco spesial", "https://static.wikia.nocookie.net/mobile-legends/images/f/fb/Wheatfield_Nightmare.jpg/revision/latest?cb=20200427031412", "https://github.com/Zlxs04/Tank/blob/main/FrancoSpecial.zip?raw=true");
		_ADDGRIDVIEW("franco starlight", "https://static.wikia.nocookie.net/mobile-legends/images/1/13/Apocalypse.jpg/revision/latest?cb=20190928154717", "https://github.com/Zlxs04/Tank/blob/main/FrancoStarlight.zip?raw=true");
		 
		_ADDGRIDVIEW("gatot kaca backup", "https://static.wikia.nocookie.net/mobile-legends/images/3/3a/Mighty_Legend.jpg/revision/latest?cb=20171018094109", "https://github.com/Zolaxis/Tank/blob/master/GatotkacaBackup.zip?raw=true");
		_ADDGRIDVIEW("gatotkaca elite", "https://static.wikia.nocookie.net/mobile-legends/images/6/6a/Arhat_King.jpg/revision/latest?cb=20180513193326", "https://github.com/Zlxs04/Tank/blob/master/GatotkacaElite.zip?raw=true");
		_ADDGRIDVIEW("gatotkaca epic", "https://static.wikia.nocookie.net/mobile-legends/images/9/90/Sentinel.jpg/revision/latest?cb=20181203155126", "https://github.com/Zlxs04/Tank/blob/main/GatotkacaEpic.zip?raw=true");
		_ADDGRIDVIEW("grock backup", "https://static.wikia.nocookie.net/mobile-legends/images/4/43/Fortress_Titan.jpg/revision/latest?cb=20200410101609", "https://github.com/Zolaxis/Tank/blob/master/GrockBackup.zip?raw=true");
		_ADDGRIDVIEW("grock elite", "https://static.wikia.nocookie.net/mobile-legends/images/9/9b/Castle_Guard.jpg/revision/latest?cb=20181124115306", "https://github.com/Zlxs04/Tank/blob/main/GrockElite.zip?raw=true");
		_ADDGRIDVIEW("grock epic", "https://static.wikia.nocookie.net/mobile-legends/images/b/bc/Codename-_Rhino.jpg/revision/latest?cb=20200610103634", "https://github.com/Zlxs04/Tank/blob/main/GrockEpic.zip?raw=true");
		_ADDGRIDVIEW("grock starlight", "https://static.wikia.nocookie.net/mobile-legends/images/5/55/Iceland_Golem.jpg/revision/latest?cb=20191028161741", "https://github.com/Zlxs04/Tank/blob/main/GrockStarlight.zip?raw=true");
		_ADDGRIDVIEW("grock venom", "https://static.wikia.nocookie.net/mobile-legends/images/7/71/V.E.N.O.M._Monitor_Lizard.jpg/revision/latest?cb=20190522170817", "https://github.com/Zlxs04/Tank/blob/main/GrockVenom.zip?raw=true");
		_ADDGRIDVIEW("hilda Elite", "https://static.wikia.nocookie.net/mobile-legends/images/5/56/Power_of_Megalith.jpg/revision/latest?cb=201710180229034", "https://github.com/Zlxs04/Tank/blob/main/HildaElite.zip?raw=true");
		_ADDGRIDVIEW("hilda zodiac", "https://static.wikia.nocookie.net/mobile-legends/images/4/4f/Sacred_Guard.jpg/revision/latest?cb=20180716111406", "https://github.com/Zlxs04/Tank/blob/main/HildaZodiac.zip?raw=true");
		 
		_ADDGRIDVIEW("jhonson backup", "https://static.wikia.nocookie.net/mobile-legends/images/f/fa/Mustang.jpg/revision/latest?cb=20190615172803", "https://github.com/Zolaxis/Tank/blob/master/JohnsonBackup.zip?raw=true");
		_ADDGRIDVIEW("jhonson elite", "https://static.wikia.nocookie.net/mobile-legends/images/9/93/Jeepney_Racer.jpg/revision/latest?cb=20181031101653", "https://github.com/Zlxs04/Tank/blob/main/JohnsonElite.zip?raw=true");
		_ADDGRIDVIEW("jhonson hotwils", "https://static.wikia.nocookie.net/mobile-legends/images/6/63/Iron-clad_Bastion_Statue.jpg/revision/latest?cb=20190825091021", "https://github.com/Zlxs04/Tank/blob/main/JohnsonDeathRide.zip?raw=true");
		_ADDGRIDVIEW("jhonson epic", "https://static.wikia.nocookie.net/mobile-legends/images/e/e4/Wreck_King.jpg/revision/latest?cb=20190613131227", "https://github.com/Zlxs04/Tank/blob/main/JohnsonEpic.zip?raw=true");
		_ADDGRIDVIEW("jhonson spesial", "https://static.wikia.nocookie.net/mobile-legends/images/6/68/Automata.jpg/revision/latest?cb=20180523132440", "https://github.com/Zlxs04/Tank/blob/main/JohnsonDeathRide.zip?raw=true");
		_ADDGRIDVIEW("kufra backup", "https://static.wikia.nocookie.net/mobile-legends/images/9/91/Desert_Tyrant.jpg/revision/latest?cb=20200922055648", "https://github.com/Zolaxis/Tank/blob/master/KhufraBackup.zip?raw=true");
		_ADDGRIDVIEW("kufra elite", "https://static.wikia.nocookie.net/mobile-legends/images/9/95/Apophis.jpg/revision/latest?cb=20200922055626", "https://github.com/Zlxs04/Tank/blob/main/KhufraElite.zip?raw=true");
		_ADDGRIDVIEW("kufra epic", "https://static.wikia.nocookie.net/mobile-legends/images/1/19/Volcanic_Overlord.jpg/revision/latest?cb=20200922055616", "https://github.com/Zolaxis/Tank/blob/master/KhufraEpic.zip?raw=true");
		_ADDGRIDVIEW("kifra spesial", "https://static.wikia.nocookie.net/mobile-legends/images/7/75/Gentleman_Thief.jpg/revision/latest?cb=20200922055643", "https://github.com/Zlxs04/Tank/blob/main/KhufraSpecial.zip?raw=true");
		_ADDGRIDVIEW("tigreal Lightbron", "https://static.wikia.nocookie.net/mobile-legends/images/c/cb/Lightborn_-_Defender.jpg/revision/latest?cb=20191115134811", "https://github.com/Zlxs04/Tank/blob/main/TigrealLightborn.zip?raw=true");
		_ADDGRIDVIEW("uranus backup", "https://static.wikia.nocookie.net/mobile-legends/images/9/9b/Aethereal_Defender.jpg/revision/latest?cb=20180803212453", "https://github.com/Zolaxis/Tank/blob/master/UranusBackup.zip?raw=true");
		_ADDGRIDVIEW("uranus epic", "https://static.wikia.nocookie.net/mobile-legends/images/5/5d/Video-Game_Dominator.jpg/revision/latest?cb=20190719173700", "https://github.com/Zlxs04/Tank/blob/main/UranusEpic.zip?raw=true");
		_ADDGRIDVIEW("uranus magma", "https://static.wikia.nocookie.net/mobile-legends/images/d/d6/Mech_Protector.jpg/revision/latest?cb=20190307081810", "https://github.com/Zlxs04/Tank/blob/main/UranusMechProtector.zip?raw=true");
		_ADDGRIDVIEW("uranus pinbal", "https://static.wikia.nocookie.net/mobile-legends/images/7/78/Pinball_Machine.jpg/revision/latest?cb=20200422031612", "https://github.com/Zlxs04/Tank/blob/main/UranusPinballMachine.zip?raw=true");
		_ADDGRIDVIEW("Baxia", "https://static.wikia.nocookie.net/mobile-legends/images/5/53/Badass_Roller.jpg/revision/latest?cb=20200912101901", "https://github.com/Zlxs04/Tank/blob/main/BaxiaElite.zip?raw=true");
		_ADDGRIDVIEW("Hylos Spesial", "https://static.wikia.nocookie.net/mobile-legends/images/f/f8/Phantom_Seer.jpg/revision/latest?cb=20180815090027", "https://github.com/Zlxs04/Tank/blob/main/HylosSpecial.zip?raw=true");
		 
		_ADDGRIDVIEW("alice backup", "https://static.wikia.nocookie.net/mobile-legends/images/e/ee/Queen_of_the_Apocalypse_%28rework%29.jpg/revision/latest?cb=20200607085015", "https://github.com/Zolaxis/Tank/blob/master/AliceBackup.zip?raw=true");
		_ADDGRIDVIEW("alice epic", "https://static.wikia.nocookie.net/mobile-legends/images/b/be/Wizardry_Teacher_%28rework%29.jpg/revision/latest?cb=20200607085600", "https://github.com/Zlxs04/Mage/blob/main/AliceEpic.zip?raw=true");
		_ADDGRIDVIEW("alice spesial", "https://static.wikia.nocookie.net/mobile-legends/images/2/20/Divine_Owl.jpg/revision/latest?cb=20200607085637", "https://github.com/Zlxs04/Mage/blob/main/AliceSpecial.zip?raw=true");
		_ADDGRIDVIEW("alice starlight", "https://static.wikia.nocookie.net/mobile-legends/images/e/e6/Steam_Glider.jpg/revision/latest?cb=20200607085646", "https://github.com/Zlxs04/Mage/blob/main/AliceStarlight.zip?raw=true");
		_ADDGRIDVIEW("balmon backup", "https://static.wikia.nocookie.net/mobile-legends/images/a/a1/Berserker_%28rework%29.jpg/revision/latest?cb=20200912120800", "https://github.com/Zolaxis/Tank/blob/master/BalmondBackup.zip?raw=true");
		_ADDGRIDVIEW("balmon elite", "https://static.wikia.nocookie.net/mobile-legends/images/d/d7/Savage_Hunter.jpg/revision/latest?cb=20200912120824", "https://github.com/Zolaxis/Tank/blob/master/BalmondElite.zip?raw=true");
		_ADDGRIDVIEW("balmon magma", "https://static.wikia.nocookie.net/mobile-legends/images/2/24/Ghoul%27s_Fury_%28rework%29.jpg/revision/latest?cb=20200912120811", "https://github.com/Zolaxis/Tank/blob/master/BalmondMagma.zip?raw=true");
		_ADDGRIDVIEW("balmon spesial", "https://static.wikia.nocookie.net/mobile-legends/images/0/0c/Savage_Pointguard.jpg/revision/latest?cb=20200912120830", "https://github.com/Zolaxis/Tank/blob/master/BalmondSpecial.zip?raw=true");
		_ADDGRIDVIEW("lolita backup", "https://static.wikia.nocookie.net/mobile-legends/images/9/9e/Steel_Elf.jpg/revision/latest?cb=20200229005255", "https://github.com/Zolaxis/Tank/blob/master/LolitaBackup.zip?raw=true");
		_ADDGRIDVIEW("lolita helowin", "https://static.wikia.nocookie.net/mobile-legends/images/5/57/Impish_Trickster.jpg/revision/latest?cb=20171104134953", "https://github.com/Zolaxis/Tank/blob/master/LolitaSpecialHalloween.zip?raw=true");
		_ADDGRIDVIEW("lolita spesial linon", "https://static.wikia.nocookie.net/mobile-legends/images/4/40/Lion_Dance.jpg/revision/latest?cb=20200605061251", "https://github.com/Zolaxis/Tank/blob/master/LolitaSpecialLion.zip?raw=true");
		_ADDGRIDVIEW("minotour beckup", "https://static.wikia.nocookie.net/mobile-legends/images/2/28/Son_of_Minos.jpg/revision/latest?cb=20180522120817", "https://github.com/Zolaxis/Tank/blob/master/MinotaurBackup.zip?raw=true");
		_ADDGRIDVIEW("minotour elite", "https://static.wikia.nocookie.net/mobile-legends/images/e/e1/Sacred_Hammer.jpg/revision/latest?cb=20180915095749", "https://github.com/Zolaxis/Tank/blob/master/MinotaurElite.zip?raw=true");
		_ADDGRIDVIEW("minotour zodiac", "https://static.wikia.nocookie.net/mobile-legends/images/d/d8/Taurus.jpg/revision/latest?cb=20190422171402", "https://github.com/Zolaxis/Tank/blob/master/MinotaurZodiac.zip?raw=true");
		 
		_ADDGRIDVIEW("tigreal backup", "https://static.wikia.nocookie.net/mobile-legends/images/5/57/Warrior_of_Dawn_%28rework%29.jpg/revision/latest?cb=20201009122407", "https://github.com/Zolaxis/Tank/blob/master/TigrealBackup.zip?raw=true");
	}
	
	
	public void _MAIN_MENU4 () {
		_ADDGRIDVIEW("fanny backup", "https://static.wikia.nocookie.net/mobile-legends/images/a/a4/Blade_Dancer.jpg/revision/latest?cb=20200528122124", "https://github.com/Zolaxis/Assasin/blob/master/FannyBackupFile.zip?raw=true");
		_ADDGRIDVIEW("fanny lafeguard", "https://static.wikia.nocookie.net/mobile-legends/images/5/54/Lifeguard.jpg/revision/latest?cb=20200528122358", "https://github.com/Zlxs04/Assasin/blob/main/FannyLifeguard.zip?raw=true");
		_ADDGRIDVIEW("fanny Lightroom", "https://static.wikia.nocookie.net/mobile-legends/images/d/d6/Lightborn_-_Ranger.jpg/revision/latest?cb=20200610105435", "https://github.com/Zlxs04/Assasin/blob/main/FannyLightborn.zip?raw=true");
		_ADDGRIDVIEW("fanny royal", "https://static.wikia.nocookie.net/mobile-legends/images/9/9e/Royal_Cavalry.jpg/revision/latest?cb=20200528122550", "https://github.com/Zolaxis/Assasin/blob/master/FannyRoyalCalvary.zip?raw=true");
		_ADDGRIDVIEW("fanny skylark", "https://static.wikia.nocookie.net/mobile-legends/images/b/b3/Skylark.jpg/revision/latest?cb=20190325165754", "https://github.com/Zlxs04/Assasin/blob/main/FannyEpic.zip?raw=true");
		_ADDGRIDVIEW("fanny spesial", "https://static.wikia.nocookie.net/mobile-legends/images/8/87/Punk_Princess_%28rework%29.jpg/revision/latest?cb=20200904035645", "https://github.com/Zolaxis/Assasin/blob/master/FannySpecialRevampNew.zip?raw=true");
		_ADDGRIDVIEW("fanny starlight", "https://static.wikia.nocookie.net/mobile-legends/images/9/9e/Royal_Cavalry.jpg/revision/latest?cb=20200528122550", "https://github.com/Zlxs04/Assasin/blob/main/FannyStarlight.zip?raw=true");
		_ADDGRIDVIEW("gs gusion backup", "https://static.wikia.nocookie.net/mobile-legends/images/9/90/Holy_Blade.jpg/revision/latest?cb=20200922023903", "https://github.com/Zlxs04/Assasin/blob/main/GusionElite.zip?raw=true");
		_ADDGRIDVIEW("gs gusion cosmic golen", "https://static.wikia.nocookie.net/mobile-legends/images/9/92/Hairstylist.jpg/revision/latest?cb=20200922023856", "https://github.com/Zlxs04/Assasin/blob/main/GusionLegend.zip?raw=true");
		_ADDGRIDVIEW("gs gusion venom", "https://static.wikia.nocookie.net/mobile-legends/images/8/89/V.E.N.O.M._Emperor_Scorpion.jpg/revision/latest?cb=20200922023932", "https://github.com/Zlxs04/Assasin/blob/main/GusionSpecial.zip?raw=true");
		 
		_ADDGRIDVIEW("gs gusion kof", "https://static.wikia.nocookie.net/mobile-legends/images/6/6d/K%27.jpg/revision/latest?cb=20200427085117", "https://github.com/Zlxs04/Assasin/blob/main/GusionKOF.zip?raw=true");
		_ADDGRIDVIEW("gs gusion legends", "https://static.wikia.nocookie.net/mobile-legends/images/d/d7/Cosmic_Gleam.jpg/revision/latest?cb=20200922023839", "https://github.com/Zlxs04/Assasin/blob/main/GusionLegend.zip?raw=true");
		_ADDGRIDVIEW("hanzo backup", "https://static.wikia.nocookie.net/mobile-legends/images/9/9d/Hanzo_Akuma_Ninja.jpg/revision/latest?cb=20181101104759", "https://github.com/Zlxs04/Assasin/blob/main/HanzoElite.zip?raw=true");
		_ADDGRIDVIEW("hanzo spesial", "https://static.wikia.nocookie.net/mobile-legends/images/6/6c/Insidious_Tutor.jpg/revision/latest?cb=20200529123723", "https://github.com/Zlxs04/Assasin/blob/main/HanzoSpecial.zip?raw=true");
		_ADDGRIDVIEW("hayabusa backup", "https://static.wikia.nocookie.net/mobile-legends/images/4/40/Crimson_Shadow.jpg/revision/latest?cb=20200604114323", "https://github.com/Zolaxis/Assasin/blob/master/HayabusaBackup.zip?raw=true");
		_ADDGRIDVIEW("hayabusa elite", "https://static.wikia.nocookie.net/mobile-legends/images/7/70/Future_Enforcer.jpg/revision/latest?cb=20180609225317", "https://github.com/Zlxs04/Assasin/blob/main/HayabusaElite.zip?raw=true");
		_ADDGRIDVIEW("hayabusa epic", "https://static.wikia.nocookie.net/mobile-legends/images/8/83/Shadow_of_Obscurity.jpg/revision/latest?cb=20200501063319", "https://github.com/Zlxs04/Assasin/blob/main/HayabusaEpic.zip?raw=true");
		_ADDGRIDVIEW("hayabusa starlight", "https://static.wikia.nocookie.net/mobile-legends/images/2/23/Biological_Weapon.jpg/revision/latest?cb=20200707114417", "https://github.com/Zlxs04/Assasin/blob/main/HayabusaAnnualStarlight.zip?raw=true");
		_ADDGRIDVIEW("hc helcrut backup", "https://static.wikia.nocookie.net/mobile-legends/images/8/8f/Shadowbringer.jpg/revision/latest?cb=20171225085913", "https://github.com/Zolaxis/Assasin/blob/master/HelcurtBackup.zip?raw=true");
		_ADDGRIDVIEW("hc helcrut kyubi", "https://static.wikia.nocookie.net/mobile-legends/images/7/7d/Ice_Scythe.jpg/revision/latest?cb=20181025075554", "https://github.com/Zlxs04/Assasin/blob/main/HelcurtElite.zip?raw=true");
		 
		_ADDGRIDVIEW("hc helcrut zodiac", "https://static.wikia.nocookie.net/mobile-legends/images/3/3f/Scorpio.jpg/revision/latest?cb=20200505122900", "https://github.com/Zlxs04/Assasin/blob/main/HelcurtZodiac.zip?raw=true");
		_ADDGRIDVIEW("karina backup", "https://static.wikia.nocookie.net/mobile-legends/images/4/42/Phantom_Blade_%28rework%29.jpg/revision/latest?cb=20190824072152", "https://github.com/Zolaxis/Assasin/blob/master/KarinaBackup.zip?raw=true");
		_ADDGRIDVIEW("karina epic", "https://static.wikia.nocookie.net/mobile-legends/images/3/32/Doom_Duelist.jpg/revision/latest?cb=20200915095224", "https://github.com/Zlxs04/Assasin/blob/main/KarinaEpic.zip?raw=true");
		_ADDGRIDVIEW("karina zodiac", "https://static.wikia.nocookie.net/mobile-legends/images/5/50/Gemini_-_Halo.jpg/revision/latest?cb=20200609125459", "https://github.com/Zlxs04/Assasin/blob/main/KarinaZodiac.zip?raw=true");
		_ADDGRIDVIEW("Karina Kof", "https://static.wikia.nocookie.net/mobile-legends/images/3/34/Leona.jpg/revision/latest?cb=20200917060146", "https://github.com/Zlxs04/Assasin/blob/main/KarinaKOF.zip?raw=true");
		_ADDGRIDVIEW("Karina Elite", "https://static.wikia.nocookie.net/mobile-legends/images/2/25/Christmas_Carnival_%28Karina%29.jpg/revision/latest?cb=20200915095215", "https://github.com/Zlxs04/Assasin/blob/main/KarinaElite.zip?raw=true");
		_ADDGRIDVIEW("lancelot backup", "https://static.wikia.nocookie.net/mobile-legends/images/b/b8/Perfumed_Knight.jpg/revision/latest?cb=20200605062244", "https://github.com/Zolaxis/Assasin/blob/master/LancelotBackup.zip?raw=true");
		_ADDGRIDVIEW("lancelot frontal khnaight", "https://static.wikia.nocookie.net/mobile-legends/images/6/6b/Floral_Knight.jpg/revision/latest?cb=20190708100903", "https://github.com/Zlxs04/Assasin/blob/main/LancelotFloralKnight.zip?raw=true");
		_ADDGRIDVIEW("lancelot hero", "https://static.wikia.nocookie.net/mobile-legends/images/5/57/Swordmaster.jpg/revision/latest?cb=20200820073630", "https://github.com/Zlxs04/Assasin/blob/main/LancelotHero.zip?raw=true");
		_ADDGRIDVIEW("lancelot royal matador", "https://static.wikia.nocookie.net/mobile-legends/images/e/e2/Royal_Matador.png/revision/latest?cb=20180423074756", "https://github.com/Zlxs04/Assasin/blob/main/LancelotRoyalMatador.zip?raw=true");
		_ADDGRIDVIEW("lacelot zodiac", "https://static.wikia.nocookie.net/mobile-legends/images/d/dc/Pisces.jpg/revision/latest?cb=20200605062322", "https://github.com/Zlxs04/Assasin/blob/main/LancelotZodiac.zip?raw=true");
		_ADDGRIDVIEW("ling backup", "https://static.wikia.nocookie.net/mobile-legends/images/f/fa/Cyan_Finch.jpg/revision/latest?cb=20200604111720", "https://github.com/Zolaxis/Assasin/blob/master/LingBackup.zip?raw=true");
		 
		_ADDGRIDVIEW("ling epic", "https://static.wikia.nocookie.net/mobile-legends/images/5/52/Night_Shade.jpg/revision/latest?cb=20200812080715", "https://github.com/Zlxs04/Assasin/blob/main/LingEpic.zip?raw=true");
		_ADDGRIDVIEW("ling night slide", "https://static.wikia.nocookie.net/mobile-legends/images/5/52/Night_Shade.jpg/revision/latest?cb=20200812080715", "https://github.com/Zlxs04/Assasin/blob/main/LingSpecial.zip?raw=true");
		_ADDGRIDVIEW("ling starlight", "https://static.wikia.nocookie.net/mobile-legends/images/6/69/Street_Punk.jpg/revision/latest?cb=20200610110032", "https://github.com/Zlxs04/Assasin/blob/main/LingStarlight.zip?raw=true");
		_ADDGRIDVIEW("natalia backup", "https://static.wikia.nocookie.net/mobile-legends/images/4/42/Bright_Claw_%28rework%29.jpg/revision/latest?cb=20200915100250", "https://github.com/Zolaxis/Assasin/blob/master/NataliaBackup.zip?raw=true");
		_ADDGRIDVIEW("natalia cyber", "https://static.wikia.nocookie.net/mobile-legends/images/e/ec/Cyber_Spectre.jpg/revision/latest?cb=20200915100303", "https://github.com/Zlxs04/Assasin/blob/main/NataliaCyberSpectre.zip?raw=true");
		_ADDGRIDVIEW("natalia spesial", "https://static.wikia.nocookie.net/mobile-legends/images/7/7d/Midnight_Raven.jpg/revision/latest?cb=20200915100336", "https://github.com/Zlxs04/Assasin/blob/main/NataliaGrimStrangler.zip?raw=true");
		_ADDGRIDVIEW("saber backup", "https://static.wikia.nocookie.net/mobile-legends/images/6/68/Wandering_Sword.jpg/revision/latest?cb=20201009122203", "https://github.com/Zolaxis/Assasin/blob/master/SaberBackup.zip?raw=true");
		_ADDGRIDVIEW("saber epic", "https://static.wikia.nocookie.net/mobile-legends/images/d/de/Onimaru.jpg/revision/latest?cb=20200915101031", "https://github.com/Zlxs04/Assasin/blob/main/SaberOnimaru.zip?raw=true");
		_ADDGRIDVIEW("saber legends", "https://static.wikia.nocookie.net/mobile-legends/images/e/ef/Codename_-_Storm_%28rework%29.jpg/revision/latest?cb=20200607071003", "https://github.com/Zlxs04/Assasin/blob/main/SaberLegend.zip?raw=true");
		_ADDGRIDVIEW("saber starlight", "https://static.wikia.nocookie.net/mobile-legends/images/c/ca/Fullmetal_Ronin.jpg/revision/latest?cb=20200915101023", "https://github.com/Zlxs04/Assasin/blob/main/SaberStarlight.zip?raw=true");
		 
		_ADDGRIDVIEW("selena backup", "https://static.wikia.nocookie.net/mobile-legends/images/a/ae/Abyssal_Witch.jpg/revision/latest?cb=20180424143620", "https://github.com/Zolaxis/Assasin/blob/master/SelenaBackupFile.zip?raw=true");
		_ADDGRIDVIEW("selena starlight", "https://static.wikia.nocookie.net/mobile-legends/images/3/38/Double_Identity.jpg/revision/latest?cb=20200612022611", "https://github.com/Zlxs04/Assasin/blob/main/SelenaStarlight.zip?raw=true");
		_ADDGRIDVIEW("selena thunder flas", "https://static.wikia.nocookie.net/mobile-legends/images/1/13/Thunder_Flash.jpg/revision/latest?cb=20200612022733", "https://github.com/Zlxs04/Assasin/blob/main/SelenaThunderFlash.zip?raw=true");
		_ADDGRIDVIEW("selena virus", "https://static.wikia.nocookie.net/mobile-legends/images/4/4c/Virus.jpg/revision/latest?cb=20200610110308", "https://github.com/Zlxs04/Assasin/blob/main/SelenaVirus.zip?raw=true");
		_ADDGRIDVIEW("selena zodiac", "https://static.wikia.nocookie.net/mobile-legends/images/a/ad/Gemini_-_Shadow.jpg/revision/latest?cb=20200605053941", "https://github.com/Zlxs04/Assasin/blob/main/SelenaZodiac.zip?raw=true");
		_ADDGRIDVIEW("Banedeta Starlight", "https://static.wikia.nocookie.net/mobile-legends/images/e/e1/Street_Blow.jpg/revision/latest?cb=20201224080929", "https://github.com/Zlxs04/Assasin/blob/main/BenedettaStarlight.zip?raw=true");
	}
	
	
	public void _MAIN_MENU3 () {
		_ADDGRIDVIEW("bruno firebolt", "https://static.wikia.nocookie.net/mobile-legends/images/7/74/Firebolt.jpg/revision/latest?cb=20200605113050", "https://github.com/Zlxs04/Marksman/blob/main/BrunoFirebolt.zip?raw=true");
		_ADDGRIDVIEW("bruno spesial", "https://static.wikia.nocookie.net/mobile-legends/images/3/33/Vanguard_Elite_%28rework%29.jpg/revision/latest?cb=20200605113145", "https://github.com/Zolaxis/Marksman/blob/master/BrunoSpecial.zip?raw=true");
		_ADDGRIDVIEW("bruno street football", "https://static.wikia.nocookie.net/mobile-legends/images/0/0f/Street_Football.jpg/revision/latest?cb=20200605113339", "https://github.com/Zolaxis/Marksman/blob/master/BrunoStreetFootball.zip?raw=true");
		_ADDGRIDVIEW("bruno elite", "https://static.wikia.nocookie.net/mobile-legends/images/b/bb/PSG_Striker.png/revision/latest?cb=20200208013826", "https://github.com/Zolaxis/Marksman/blob/master/BrunoVanguardElite.zip?raw=true");
		_ADDGRIDVIEW("claude backup", "https://static.wikia.nocookie.net/mobile-legends/images/0/08/Partners_in_Crime.png/revision/latest?cb=20180616143341", "https://github.com/Zolaxis/Marksman/blob/master/ClaudeBackup.zip?raw=true");
		_ADDGRIDVIEW("claude blazing", "https://static.wikia.nocookie.net/mobile-legends/images/2/2f/Blazing_Trace_wall.jpg/revision/latest?cb=20201126072839", "https://github.com/Zolaxis/Marksman/blob/master/ClaudeBlazing.zip?raw=true");
		_ADDGRIDVIEW("calude Christmas", "https://static.wikia.nocookie.net/mobile-legends/images/d/d0/Christmas_Carnival_%28Claude%29.jpg/revision/latest?cb=20200427034912", "https://github.com/Zolaxis/Marksman/blob/master/ClaudeChristmasCarnival.zip?raw=true");
		_ADDGRIDVIEW("claude lifguard", "https://static.wikia.nocookie.net/mobile-legends/images/5/54/Lifeguard.jpg/revision/latest?cb=20200528122358", "https://github.com/Zolaxis/Marksman/blob/master/ClaudeLifeguard.zip?raw=true");
		_ADDGRIDVIEW("claude metcha drahon", "https://static.wikia.nocookie.net/mobile-legends/images/3/32/Mecha_Dragon.jpg/revision/latest?cb=20200427034523", "https://github.com/Zolaxis/Marksman/blob/master/ClaudeMechaDragon.zip?raw=true");
		_ADDGRIDVIEW("claude starlight", "https://static.wikia.nocookie.net/mobile-legends/images/7/72/Plunderous_Pirate.jpg/revision/latest?cb=20181110154826", "https://github.com/Zolaxis/Marksman/blob/master/ClaudeStarlight.zip?raw=true");
		//marksman
		_ADDGRIDVIEW("granger agen z", "https://static.wikia.nocookie.net/mobile-legends/images/5/5b/Doomsday_Terminator.jpg/revision/latest?cb=20200422032904", "https://github.com/Zolaxis/Marksman/blob/master/GrangerAgentZ.zip?raw=true");
		_ADDGRIDVIEW("granger backup", "https://static.wikia.nocookie.net/mobile-legends/images/1/17/Death_Chanter.jpg/revision/latest?cb=20200912121852", "https://github.com/Zolaxis/Marksman/blob/master/GrangerBackup.zip?raw=true");
		_ADDGRIDVIEW("granger biosorder", "https://static.wikia.nocookie.net/mobile-legends/images/a/a6/Biosoldier.jpg/revision/latest?cb=20200912121844", "https://github.com/Zolaxis/Marksman/blob/master/GrangerBiosoldier.zip?raw=true");
		_ADDGRIDVIEW("granger epic", "https://static.wikia.nocookie.net/mobile-legends/images/8/8c/Agent_Z.jpg/revision/latest?cb=20200917131917", "https://github.com/Zolaxis/Marksman/blob/master/GrangerEpic.zip?raw=true");
		_ADDGRIDVIEW("granger Lightroom", "https://static.wikia.nocookie.net/mobile-legends/images/5/5d/Lightborn_-_Overrider.jpg/revision/latest?cb=20200912121908", "https://github.com/Zolaxis/Marksman/blob/master/GrangerLightborn.zip?raw=true");
		_ADDGRIDVIEW("hanabi backup", "https://static.wikia.nocookie.net/mobile-legends/images/9/97/Scarlet_Flower.jpg/revision/latest?cb=20200513061717", "https://github.com/Zolaxis/Marksman/blob/master/HanabiBackup.zip?raw=true");
		_ADDGRIDVIEW("hanabi elite", "https://static.wikia.nocookie.net/mobile-legends/images/8/8b/Viper.jpg/revision/latest?cb=20200605063724", "https://github.com/Zolaxis/Marksman/blob/master/HanabiElite.zip?raw=true");
		_ADDGRIDVIEW("hanabi epic", "https://static.wikia.nocookie.net/mobile-legends/images/c/c2/Rakshesha.jpg/revision/latest?cb=20200513061910", "https://github.com/Zolaxis/Marksman/blob/master/HanabiEpic.zip?raw=true");
		_ADDGRIDVIEW("hanabi starlight", "https://static.wikia.nocookie.net/mobile-legends/images/6/6c/Fiery_Moth.jpg/revision/latest?cb=20200605054939", "https://github.com/Zolaxis/Marksman/blob/master/HanabiStarlight.zip?raw=true");
		 
		_ADDGRIDVIEW("hanabi venom", "https://static.wikia.nocookie.net/mobile-legends/images/c/c0/V.E.N.O.M._Nephila.jpg/revision/latest?cb=20200605063445", "https://github.com/Zolaxis/Marksman/blob/master/HanabiVenom.zip?raw=true");
		_ADDGRIDVIEW("bruno backup", "https://static.wikia.nocookie.net/mobile-legends/images/2/27/The_Protector_%28rework%29.jpg/revision/latest?cb=20200605113238", "https://github.com/Zolaxis/Marksman/blob/master/brunobackup.zip?raw=true");
		_ADDGRIDVIEW("iritel astral wander", "https://static.wikia.nocookie.net/mobile-legends/images/f/fb/Astral_Wanderer.jpg/revision/latest?cb=20191011111332", "https://github.com/Zolaxis/Marksman/blob/master/IrithelAstralWanderer.zip?raw=true");
		_ADDGRIDVIEW("iritel backup", "https://static.wikia.nocookie.net/mobile-legends/images/f/f3/Jungle_Heart.jpg/revision/latest?cb=20180123085139", "https://github.com/Zolaxis/Marksman/blob/master/IrithelBackup.zip?raw=true");
		_ADDGRIDVIEW("iritel hell fire", "https://static.wikia.nocookie.net/mobile-legends/images/d/d2/Hellfire.jpg/revision/latest?cb=20180411062903", "https://github.com/Zolaxis/Marksman/blob/master/IrithelHellFire.zip?raw=true");
		_ADDGRIDVIEW("iritel starlight", "https://static.wikia.nocookie.net/mobile-legends/images/6/65/Night_Arrow.jpg/revision/latest?cb=20180404121832", "https://github.com/Zolaxis/Marksman/blob/master/IrithelStarlight.zip?raw=true");
		_ADDGRIDVIEW("iritel zodiac", "https://static.wikia.nocookie.net/mobile-legends/images/a/a8/Sagittarius.jpg/revision/latest?cb=20181124123105", "https://github.com/Zolaxis/Marksman/blob/master/IrithelZodiac.zip?raw=true");
		_ADDGRIDVIEW("kerrie anual starlight", "https://static.wikia.nocookie.net/mobile-legends/images/2/2b/Dragon_Queen.jpg/revision/latest?cb=20180404124021", "https://github.com/Zolaxis/Marksman/blob/master/KarrieAnnualStarlight.zip?raw=true");
		_ADDGRIDVIEW("karrie backup", "https://static.wikia.nocookie.net/mobile-legends/images/b/bf/Lost_Star.jpg/revision/latest?cb=20171019091823", "https://github.com/Zolaxis/Marksman/blob/master/KarrieBackup.zip?raw=true");
		_ADDGRIDVIEW("karrie epic", "https://static.wikia.nocookie.net/mobile-legends/images/1/1d/Hawkwatch.jpg/revision/latest?cb=20190325163257", "https://github.com/Zolaxis/Marksman/blob/master/KarrieEpic.zip?raw=true");
		 
		_ADDGRIDVIEW("karrie gilgirl", "https://static.wikia.nocookie.net/mobile-legends/images/d/d1/Gill-Girl.jpg/revision/latest?cb=20200109083327", "https://github.com/Zolaxis/Marksman/blob/master/KarrieGilGirl.zip?raw=true");
		_ADDGRIDVIEW("kimmi astrocat", "https://static.wikia.nocookie.net/mobile-legends/images/2/20/Astrocat.jpg/revision/latest?cb=20200427033852", "https://github.com/Zolaxis/Marksman/blob/master/KimmyAstrocat.zip?raw=true");
		_ADDGRIDVIEW("kimmi backup", "https://static.wikia.nocookie.net/mobile-legends/images/0/00/Splat_Queen.jpg/revision/latest?cb=20180907112406", "https://github.com/Zolaxis/Marksman/blob/master/KimmyBackup.zip?raw=true");
		_ADDGRIDVIEW("kimmi epic", "https://static.wikia.nocookie.net/mobile-legends/images/5/55/Frost_Wing.jpg/revision/latest?cb=20200827013427", "https://github.com/Zolaxis/Marksman/blob/master/KimmyEpic.zip?raw=true");
		_ADDGRIDVIEW("layla blazing", "https://static.wikia.nocookie.net/mobile-legends/images/3/32/Blazing_Gun.jpg/revision/latest?cb=20201114053528", "https://github.com/Zolaxis/Marksman/blob/master/LaylaBlazing.zip?raw=true");
		_ADDGRIDVIEW("layla backup", "https://static.wikia.nocookie.net/mobile-legends/images/4/45/Energy_Gunner.jpg/revision/latest?cb=20201009122653", "https://github.com/Zolaxis/Marksman/blob/master/LesleyBackup.zip?raw=true");
		_ADDGRIDVIEW("layla saber", "https://static.wikia.nocookie.net/mobile-legends/images/1/15/Breacher.jpg/revision/latest?cb=20200427094425", "https://github.com/Zolaxis/Marksman/blob/master/LaylaSaber.zip?raw=true");
		_ADDGRIDVIEW("lesly beckup", "https://static.wikia.nocookie.net/mobile-legends/images/3/32/Sniper.jpg/revision/latest?cb=20180523135443", "https://github.com/Zolaxis/Marksman/blob/master/LesleyBackup.zip?raw=true");
		_ADDGRIDVIEW("lesly epic", "https://static.wikia.nocookie.net/mobile-legends/images/0/05/Stellaris_Ghost.jpg/revision/latest?cb=20180825203822", "https://github.com/Zolaxis/Marksman/blob/master/LesleyEpic.zip?raw=true");
		_ADDGRIDVIEW("lesly legends", "https://static.wikia.nocookie.net/mobile-legends/images/7/73/Angelic_Agent.jpg/revision/latest?cb=20200610103311", "https://github.com/Zolaxis/Marksman/blob/master/LesleyLegend.zip?raw=true");
		 
		_ADDGRIDVIEW("lesly starlight", "https://static.wikia.nocookie.net/mobile-legends/images/a/ae/Lethal_Lady.jpg/revision/latest?cb=20200610105346", "https://github.com/Zolaxis/Marksman/blob/master/LesleyStarlight.zip?raw=true");
		_ADDGRIDVIEW("miya backup", "https://static.wikia.nocookie.net/mobile-legends/images/f/f8/Moonlight_Archer_%28revamp%29.jpg/revision/latest?cb=20200718072736", "https://github.com/Zolaxis/Marksman/blob/master/MiyaBackup.zip?raw=true");
		_ADDGRIDVIEW("miya epic", "https://static.wikia.nocookie.net/mobile-legends/images/7/79/Honor.jpg/revision/latest?cb=20200605113228", "https://github.com/Zolaxis/Marksman/blob/master/MiyaEpic.zip?raw=true");
		_ADDGRIDVIEW("miya legends", "https://static.wikia.nocookie.net/mobile-legends/images/a/a4/Modena_Butterfly_%28rework%29.jpg/revision/latest?cb=20200912095445", "https://github.com/Zolaxis/Marksman/blob/master/MiyaLegend.zip?raw=true");
		_ADDGRIDVIEW("miya swett fantasi", "https://static.wikia.nocookie.net/mobile-legends/images/7/76/Sweet_Fantasy.jpg/revision/latest?cb=20200912095509", "https://github.com/Zolaxis/Marksman/blob/master/MiyaSweetFantasy.zip?raw=true");
		_ADDGRIDVIEW("moskov backup", "https://static.wikia.nocookie.net/mobile-legends/images/7/7e/Spear_of_Quiescence.jpg/revision/latest?cb=20200427033453", "https://github.com/Zolaxis/Marksman/blob/master/MoskovBackup.zip?raw=true");
		_ADDGRIDVIEW("moskov blodspear", "https://static.wikia.nocookie.net/mobile-legends/images/1/1d/Twilight_Dragon.jpg/revision/latest?cb=20200427032436", "https://github.com/Zolaxis/Marksman/blob/master/MoskovBloodSpear.zip?raw=true");
		_ADDGRIDVIEW("moskov epic", "https://static.wikia.nocookie.net/mobile-legends/images/f/f9/Blood_Spear.jpg/revision/latest?cb=20200921123538", "https://github.com/Zolaxis/Marksman/blob/master/MoskovEpic.zip?raw=true");
		_ADDGRIDVIEW("popol kupa backup", "https://static.wikia.nocookie.net/mobile-legends/images/c/c6/Icefield_Companions.jpg/revision/latest?cb=20200610105336", "https://github.com/Zolaxis/Marksman/blob/master/PopolBackup.zip?raw=true");
		_ADDGRIDVIEW("popol kupa elite", "https://static.wikia.nocookie.net/mobile-legends/images/9/9b/Tribal_Howl.jpg/revision/latest?cb=20200820142644", "https://github.com/Zolaxis/Marksman/blob/master/PopolElite.zip?raw=true");
		_ADDGRIDVIEW("roger backup", "https://static.wikia.nocookie.net/mobile-legends/images/0/0b/Dire_Wolf_Hunter.jpg/revision/latest?cb=20180705182702", "https://github.com/Zolaxis/Marksman/blob/master/RogerBackup.zip?raw=true");
		 
		_ADDGRIDVIEW("roger pirets epic", "https://static.wikia.nocookie.net/mobile-legends/images/8/81/Phantom_Pirate.jpg/revision/latest?cb=20180906170147", "https://github.com/Zolaxis/Marksman/blob/master/RogerPirateEpic.zip?raw=true");
		_ADDGRIDVIEW("roger dr beast", "https://static.wikia.nocookie.net/mobile-legends/images/9/9a/Dr._Beast_%28rework%29.jpg/revision/latest?cb=20200917132236", "https://github.com/Zolaxis/Marksman/blob/master/RogerDrBeast.zip?raw=true");
		_ADDGRIDVIEW("wanwan backup", "https://static.wikia.nocookie.net/mobile-legends/images/2/28/Agile_Tiger.jpg/revision/latest?cb=20191107084820", "https://github.com/Zolaxis/Marksman/blob/master/WanwanBackup.zip?raw=true");
		_ADDGRIDVIEW("wanwan elite", "https://static.wikia.nocookie.net/mobile-legends/images/c/ca/Shoujo_Commander.jpg/revision/latest?cb=20200610105943", "https://github.com/Zolaxis/Marksman/blob/master/WanwanElite.zip?raw=true");
		_ADDGRIDVIEW("wawan starlight", "https://static.wikia.nocookie.net/mobile-legends/images/a/a2/Teen_Pop.jpg/revision/latest?cb=20200812080614", "https://github.com/Zolaxis/Marksman/blob/master/WanwanStarlight.zip?raw=true");
		_ADDGRIDVIEW("yss elite", "https://static.wikia.nocookie.net/mobile-legends/images/e/e9/Apocalypse_Agent.jpg/revision/latest?cb=20171019101849", "https://github.com/Zolaxis/Marksman/blob/master/YSSElite.zip?raw=true");
		_ADDGRIDVIEW("yss epic", "https://static.wikia.nocookie.net/mobile-legends/images/8/86/Lone_Destructor.jpg/revision/latest?cb=20200427025351", "https://github.com/Zolaxis/Marksman/blob/master/YSSEpic.zip?raw=true");
		_ADDGRIDVIEW("yss backup", "https://static.wikia.nocookie.net/mobile-legends/images/3/37/Paenlong_Legend.jpg/revision/latest?cb=20200604031859", "https://github.com/Zolaxis/Marksman/blob/master/YiSunShinBackup.zip?raw=true");
	}
	
	
	public void _MAIN_MENU6 () {
		_ADDGRIDVIEW("Aurora kof", "https://static.wikia.nocookie.net/mobile-legends/images/c/cf/Kula_Diamond.jpg/revision/latest?cb=20200427084327", "https://github.com/Zlxs04/Mage/blob/main/AuroraKOF.zip?raw=true");
		_ADDGRIDVIEW("Aurora spesial", "https://static.wikia.nocookie.net/mobile-legends/images/3/3f/Foxy_Lady.jpg/revision/latest?cb=20200605055330", "https://github.com/Zlxs04/Mage/blob/main/AuroraSpecial.zip?raw=true");
		_ADDGRIDVIEW("Aurora Starlight", "https://static.wikia.nocookie.net/mobile-legends/images/3/39/Heartbreak_Empress.jpg/revision/latest?cb=20171101063632", "https://github.com/Zlxs04/Mage/blob/main/AuroraStarlight.zip?raw=true");
		_ADDGRIDVIEW("Aurora Zodiac", "https://static.wikia.nocookie.net/mobile-legends/images/a/a9/Aquarius.jpg/revision/latest?cb=20200906183315", "https://github.com/Zlxs04/Mage/blob/main/AuroraZodiac.zip?raw=true");
		_ADDGRIDVIEW("Cecilion Elite", "https://static.wikia.nocookie.net/mobile-legends/images/b/b1/Wisteria_Count.jpg/revision/latest?cb=20200612023345", "https://github.com/Zlxs04/Mage/blob/main/CecilionElite.zip?raw=true");
		_ADDGRIDVIEW("Change Elite", "https://static.wikia.nocookie.net/mobile-legends/images/f/f4/Crimson_Moon.jpg/revision/latest?cb=20200604111513", "https://github.com/Zlxs04/Mage/blob/main/ChangeElite.zip?raw=true");
		_ADDGRIDVIEW("Change epic", "https://static.wikia.nocookie.net/mobile-legends/images/c/c5/Lunar_Magic.jpg/revision/latest?cb=20200606085015", "https://github.com/Zlxs04/Mage/blob/main/ChangeEpic.zip?raw=true");
		_ADDGRIDVIEW("Change spesial", "https://static.wikia.nocookie.net/mobile-legends/images/7/77/Floral_Elfo.jpg/revision/latest?cb=20200605055239", "https://github.com/Zlxs04/Mage/blob/main/ChangeSpecial.zip?raw=true");
		_ADDGRIDVIEW("Change starlight", "https://static.wikia.nocookie.net/mobile-legends/images/9/9e/Strawberry_Parfait.jpg/revision/latest?cb=20201022085804", "https://github.com/Zlxs04/Mage/blob/main/ChangeStarlight.zip?raw=true");
		_ADDGRIDVIEW("Cyclops Elite", "https://static.wikia.nocookie.net/mobile-legends/images/4/4e/Super_Adventurer.jpeg/revision/latest?cb=20171018091453", "https://github.com/Zlxs04/Mage/blob/main/CyclopsElite.zip?raw=true");
		_ADDGRIDVIEW("Cyclops Saber", "https://static.wikia.nocookie.net/mobile-legends/images/6/62/Exploder.jpg/revision/latest?cb=20180523132609", "https://github.com/Zlxs04/Mage/blob/main/CyclopsSaber.zip?raw=true");
		_ADDGRIDVIEW("Cyclops starlight", "https://static.wikia.nocookie.net/mobile-legends/images/3/3c/Deep_Sea_Rescuer.jpg/revision/latest?cb=20180827164725", "https://github.com/Zlxs04/Mage/blob/main/CyclopsStarlight.zip?raw=true");
		_ADDGRIDVIEW("Esmeralda Elite", "https://static.wikia.nocookie.net/mobile-legends/images/9/93/Poison_Vine.jpg/revision/latest?cb=20200427030109", "https://github.com/Zlxs04/Mage/blob/main/EsmeElite.zip?raw=true");
		_ADDGRIDVIEW("Esmeralda Epic", "https://static.wikia.nocookie.net/mobile-legends/images/5/5b/Blazing_Shadow.jpg/revision/latest?cb=20201125014237", "https://github.com/Zlxs04/Mage/blob/main/EsmeEpic.zip?raw=true");
		_ADDGRIDVIEW("Esmeralda spesial", "https://static.wikia.nocookie.net/mobile-legends/images/b/b3/Lady_Thief.jpg/revision/latest?cb=20200912102253", "https://github.com/Zlxs04/Mage/blob/main/EsmeSpecial.zip?raw=true");
		_ADDGRIDVIEW("Esmeralda Starlight", "https://static.wikia.nocookie.net/mobile-legends/images/8/85/Cleopatra.jpg/revision/latest?cb=20200912102231", "https://github.com/Zlxs04/Mage/blob/main/EsmeStarlight.zip?raw=true");
		_ADDGRIDVIEW("Eudora elite", "https://static.wikia.nocookie.net/mobile-legends/images/b/bb/EudoraElite.jpg/revision/latest?cb=20201127034937", "https://github.com/Zlxs04/Mage/blob/main/EudoraElite.zip?raw=true");
		_ADDGRIDVIEW("Eudora epic", "https://static.wikia.nocookie.net/mobile-legends/images/0/09/Emerald_Enchantress_%28rework%29.jpg/revision/latest?cb=20200904035634", "https://github.com/Zlxs04/Mage/blob/main/EudoraEpic.zip?raw=true");
		_ADDGRIDVIEW("Eudora Limited", "https://static.wikia.nocookie.net/mobile-legends/images/4/4f/Vivo_Selfie_Goddess.jpg/revision/latest?cb=20200610110557", "https://github.com/Zlxs04/Mage/blob/main/EudoraLimited.zip?raw=true");
		_ADDGRIDVIEW("gord anual starlight", "https://static.wikia.nocookie.net/mobile-legends/images/d/d1/No.1_Controller.jpg/revision/latest?cb=20200501094406", "https://github.com/Zlxs04/Mage/blob/main/GordAnnualStarlight.zip?raw=true");
		_ADDGRIDVIEW("gord elite", "https://static.wikia.nocookie.net/mobile-legends/images/f/f9/Christmas_Carnival_%28Gord%29.jpg/revision/latest?cb=20200408042301", "https://github.com/Zlxs04/Mage/blob/main/GordElite.zip?raw=true");
		_ADDGRIDVIEW("gord legends", "https://static.wikia.nocookie.net/mobile-legends/images/b/bd/Conqueror.jpg/revision/latest?cb=20190908142128", "https://github.com/Zlxs04/Mage/blob/main/GordLegend.zip?raw=true");
		_ADDGRIDVIEW("harith elite", "https://static.wikia.nocookie.net/mobile-legends/images/2/2a/Stardust.jpg/revision/latest?cb=20190526181749", "https://github.com/Zlxs04/Mage/blob/main/HarithElite.zip?raw=true");
		_ADDGRIDVIEW("harith epic", "https://static.wikia.nocookie.net/mobile-legends/images/0/0e/Fashion_Expert.png/revision/latest?cb=20191118120325", "https://github.com/Zlxs04/Mage/blob/main/HarithEpic.zip?raw=true");
		_ADDGRIDVIEW("harith lighbron", "https://static.wikia.nocookie.net/mobile-legends/images/0/00/Lightborn_-_Inspirer.jpg/revision/latest?cb=20191114141449", "https://github.com/Zlxs04/Mage/blob/main/HarithLightborn.zip?raw=true");
		_ADDGRIDVIEW("harley epic", "https://static.wikia.nocookie.net/mobile-legends/images/f/ff/Great_Inventor.jpg/revision/latest?cb=20181110152856", "https://github.com/Zlxs04/Mage/blob/main/HarleyEpic.zip?raw=true");
		_ADDGRIDVIEW("harley spesial", "https://static.wikia.nocookie.net/mobile-legends/images/e/ee/Referee.jpg/revision/latest?cb=20200408214627", "https://github.com/Zlxs04/Mage/blob/main/HarleySpecial.zip?raw=true");
		_ADDGRIDVIEW("harley starlight", "https://static.wikia.nocookie.net/mobile-legends/images/e/e4/Royal_Magister.jpg/revision/latest?cb=20200408214606", "https://github.com/Zlxs04/Mage/blob/main/HarleyStarlight.zip?raw=true");
		_ADDGRIDVIEW("harley venom", "https://static.wikia.nocookie.net/mobile-legends/images/e/e5/V.E.N.O.M._Octopus.jpg/revision/latest?cb=20200605063617", "https://github.com/Zlxs04/Mage/blob/main/HarleyVenom.zip?raw=true");
		_ADDGRIDVIEW("kadita spesial", "https://static.wikia.nocookie.net/mobile-legends/images/3/3a/White_Robin.jpg/revision/latest?cb=20200912121558", "https://github.com/Zlxs04/Mage/blob/main/KaditaSpecial.zip?raw=true");
		_ADDGRIDVIEW("kagura chery witch", "https://static.wikia.nocookie.net/mobile-legends/images/c/ce/Cherry_Witch.jpg/revision/latest?cb=20200501062219", "https://github.com/Zlxs04/Mage/blob/main/KaguraCherryWitch.zip?raw=true");
		_ADDGRIDVIEW("kagura epic", "https://static.wikia.nocookie.net/mobile-legends/images/f/f9/Soryu_Maiden.jpg/revision/latest?cb=20200501062759", "https://github.com/Zlxs04/Mage/blob/main/KaguraEpic.zip?raw=true");
		_ADDGRIDVIEW("kagura sumer festival", "https://static.wikia.nocookie.net/mobile-legends/images/9/95/Summer_Festival.jpg/revision/latest?cb=20180708064045", "https://github.com/Zlxs04/Mage/blob/main/KaguraSummerFestival.zip?raw=true");
		_ADDGRIDVIEW("louyi elite", "https://static.wikia.nocookie.net/mobile-legends/images/6/65/Tenko.jpg/revision/latest?cb=20201022085105", "https://github.com/Zlxs04/Mage/blob/main/LouyiElite.zip?raw=true");
		_ADDGRIDVIEW("lunox elite", "https://static.wikia.nocookie.net/mobile-legends/images/b/b1/Cosmic_Harmony.jpg/revision/latest?cb=20200604105837", "https://github.com/Zlxs04/Mage/blob/main/LunoxElite.zip?raw=true");
		_ADDGRIDVIEW("lunox epic", "https://static.wikia.nocookie.net/mobile-legends/images/9/95/Butterfly_Seraphim.jpg/revision/latest?cb=20200603072814", "https://github.com/Zlxs04/Mage/blob/main/LunoxEpic.zip?raw=true");
		_ADDGRIDVIEW("Lunox starlight", "https://static.wikia.nocookie.net/mobile-legends/images/e/e6/Ash_Blossom.jpg/revision/latest?cb=20200505125043", "https://github.com/Zlxs04/Mage/blob/main/LunoxStarlight.zip?raw=true");
		_ADDGRIDVIEW("lunox zodiac", "https://static.wikia.nocookie.net/mobile-legends/images/5/58/Libra.jpg/revision/latest?cb=20200505124934", "https://github.com/Zlxs04/Mage/blob/main/LunoxZodiac.zip?raw=true");
		_ADDGRIDVIEW("lylia elite", "https://static.wikia.nocookie.net/mobile-legends/images/8/85/Star_Student.jpg/revision/latest?cb=20200222224354", "https://github.com/Zlxs04/Mage/blob/main/LyliaElite.zip?raw=true");
		_ADDGRIDVIEW("lylia future star", "https://static.wikia.nocookie.net/mobile-legends/images/4/4d/Future_Star.jpg/revision/latest?cb=20200510095525", "https://github.com/Zlxs04/Mage/blob/main/LyliaFutureStar.zip?raw=true");
		_ADDGRIDVIEW("lylia hoanted dol", "https://static.wikia.nocookie.net/mobile-legends/images/3/3b/Haunted_Doll.jpg/revision/latest?cb=20200929053058", "https://github.com/Zlxs04/Mage/blob/main/LyliaHauntedDoll.zip?raw=true");
		_ADDGRIDVIEW("odate auspicious", "https://static.wikia.nocookie.net/mobile-legends/images/d/d7/Mermaid_Princess.jpg/revision/latest?cb=20200413090318", "https://github.com/Zlxs04/Mage/blob/main/OdetteAuspiciousCharm.zip?raw=true");
		_ADDGRIDVIEW("odate butterfly godes", "https://static.wikia.nocookie.net/mobile-legends/images/5/5e/Butterfly_Goddess.jpg/revision/latest?cb=20200603063316", "https://github.com/Zlxs04/Mage/blob/main/OdetteButterflyGoddess.zip?raw=true");
		_ADDGRIDVIEW("odate Christmas", "https://static.wikia.nocookie.net/mobile-legends/images/2/2b/Christmas_Cheer_%28Odette%29.jpg/revision/latest?cb=20180404163828", "https://github.com/Zlxs04/Mage/blob/main/OdetteChristmasCarnival.zip?raw=true");
		_ADDGRIDVIEW("odate zodiac", "https://static.wikia.nocookie.net/mobile-legends/images/3/3b/Virgo.jpg/revision/latest?cb=20200505125748", "https://github.com/Zlxs04/Mage/blob/main/OdetteZodiac.zip?raw=true");
		_ADDGRIDVIEW("pharsa elite", "https://static.wikia.nocookie.net/mobile-legends/images/5/52/Peafowl_Pharsa.png/revision/latest?cb=20180424144839", "https://github.com/Zlxs04/Mage/blob/main/PharsaElite.zip?raw=true");
		_ADDGRIDVIEW("pharsa epic", "https://static.wikia.nocookie.net/mobile-legends/images/a/a6/Empress_Phoenix.jpg/revision/latest?cb=20200812080510", "https://github.com/Zlxs04/Mage/blob/main/PharsaEpic.zip?raw=true");
		_ADDGRIDVIEW("valir demonlord", "https://static.wikia.nocookie.net/mobile-legends/images/6/6b/Demonlord.jpg/revision/latest?cb=20201213061359", "https://github.com/Zlxs04/Mage/blob/main/ValirDemonLord.zip?raw=true");
		_ADDGRIDVIEW("valir draconic ", "https://static.wikia.nocookie.net/mobile-legends/images/a/ae/Draconic_Flame.jpg/revision/latest?cb=20200526103044", "https://github.com/Zlxs04/Mage/blob/main/ValirDraconicFlame.zip?raw=true");
		_ADDGRIDVIEW("valir starlight", "https://static.wikia.nocookie.net/mobile-legends/images/6/6d/Dictator_%28Valir%29.jpg/revision/latest?cb=20200427031710", "https://github.com/Zlxs04/Mage/blob/main/ValirStarlight.zip?raw=true");
	}
	
	
	public void _MAIN_MENU1 () {
		_ADDGRIDVIEW("Angela starlight", "https://static.wikia.nocookie.net/mobile-legends/images/c/c5/Shanghai_Maiden.jpg/revision/latest?cb=20200912121239", "https://github.com/Zlxs04/Support/blob/main/AngelaStarlight.zip?raw=true");
		_ADDGRIDVIEW("Angela sumer vibes", "https://static.wikia.nocookie.net/mobile-legends/images/1/15/Summer_Vibes.jpg/revision/latest?cb=20200912121245", "https://github.com/Zlxs04/Support/blob/main/AngelaSummerVibes.zip?raw=true");
		_ADDGRIDVIEW("angela venom", "https://static.wikia.nocookie.net/mobile-legends/images/9/9f/V.E.N.O.M._Vespid.jpg/revision/latest?cb=20200912121254", "https://github.com/Zlxs04/Support/blob/main/AngelaVenom.zip?raw=true");
		_ADDGRIDVIEW("karmila elite", "https://static.wikia.nocookie.net/mobile-legends/images/0/0a/Magician_Girl.jpg/revision/latest?cb=20200922023250", "https://github.com/Zlxs04/Support/blob/main/CarmillaElite.zip?raw=true");
		_ADDGRIDVIEW("diggie elite", "https://static.wikia.nocookie.net/mobile-legends/images/f/fc/Circus_Clown.jpg/revision/latest?cb=20200920111714", "https://github.com/Zlxs04/Support/blob/main/DiggieElite.zip?raw=true");
		_ADDGRIDVIEW("estes galaxy dominator", "https://static.wikia.nocookie.net/mobile-legends/images/0/04/Galaxy_Dominator.jpg/revision/latest?cb=20200915095612", "https://github.com/Zlxs04/Support/blob/main/EstesGalaxyDominator.zip?raw=true");
		_ADDGRIDVIEW("estes ratan dragon", "https://static.wikia.nocookie.net/mobile-legends/images/f/f5/Rattan_Dragon.jpg/revision/latest?cb=20200915095650", "https://github.com/Zlxs04/Support/blob/main/EstesRattanDragon.zip?raw=true");
		_ADDGRIDVIEW("kaja elite", "https://static.wikia.nocookie.net/mobile-legends/images/f/f9/Kaminari.jpg/revision/latest?cb=20190729174510", "https://github.com/Zlxs04/Support/blob/main/KajaElite.zip?raw=true");
		_ADDGRIDVIEW("kaja epic", "https://static.wikia.nocookie.net/mobile-legends/images/e/ea/Skyblocker.jpg/revision/latest?cb=20200427112018", "https://github.com/Zlxs04/Support/blob/main/KajaEpic.zip?raw=true");
		_ADDGRIDVIEW("kaja starlight", "https://static.wikia.nocookie.net/mobile-legends/images/1/13/Horror_Whiplash.jpg/revision/latest?cb=20200610105130", "https://github.com/Zlxs04/Support/blob/main/KajaStarlight.zip?raw=true");
		_ADDGRIDVIEW("nana epic", "https://static.wikia.nocookie.net/mobile-legends/images/7/75/Mecha_Baby.jpg/revision/latest?cb=20200915100714", "https://github.com/Zlxs04/Support/blob/main/NanaEpic.zip?raw=true");
		_ADDGRIDVIEW("nana smer party", "https://static.wikia.nocookie.net/mobile-legends/images/4/40/Sundress.jpg/revision/latest?cb=20200915100729", "https://github.com/Zlxs04/Support/blob/main/NanaSlumberParty.zip?raw=true");
		_ADDGRIDVIEW("nana wind fairy", "https://static.wikia.nocookie.net/mobile-legends/images/a/a2/Wind_Fairy.jpg/revision/latest?cb=20200915100741", "https://github.com/Zlxs04/Support/blob/main/NanaWindFairy.zip?raw=true");
		_ADDGRIDVIEW("karmila phnatom", "https://static.wikia.nocookie.net/mobile-legends/images/8/8f/Phantom_Countess.jpg/revision/latest?cb=20210131040108", "https://github.com/adefirmansyah123/MySkins/blob/main/carmila_new.zip?raw=true");
		_ADDGRIDVIEW("pharsa samba", "https://static.wikia.nocookie.net/mobile-legends/images/d/d1/Samba_Muse.jpg/revision/latest?cb=20210131041942", "https://github.com/adefirmansyah123/MySkins/blob/main/Pharsa_samba.zip?raw=true");
		_ADDGRIDVIEW("Cecilion", "https://static.wikia.nocookie.net/mobile-legends/images/d/d5/Phantom_Count.jpg/revision/latest?cb=20210131040116", "https://github.com/adefirmansyah123/MySkins/blob/main/cecilion_new.zip?raw=true");
		_ADDGRIDVIEW("gusion nigh owl", "https://static.wikia.nocookie.net/mobile-legends/images/9/9b/Night_Owl.jpg/revision/latest?cb=20210131041950", "https://github.com/adefirmansyah123/MySkins/blob/main/gs_nighowl.zip?raw=true");
		_ADDGRIDVIEW("khaled cresan", "https://static.wikia.nocookie.net/mobile-legends/images/6/6b/Crescent_Scimitar.jpg/revision/latest?cb=20210131040059", "https://github.com/adefirmansyah123/MySkins/blob/main/khaled_new.zip?raw=true");
		_ADDGRIDVIEW("kufra new", "https://static.wikia.nocookie.net/mobile-legends/images/a/a6/Dreadful_Clown.jpg/revision/latest?cb=20210131041958", "https://github.com/adefirmansyah123/MySkins/blob/main/kufradeapols.zip?raw=true");
		_ADDGRIDVIEW("louyi new", "https://static.wikia.nocookie.net/mobile-legends/images/4/43/Forest_Hymn.jpg/revision/latest?cb=20201114053955", "https://github.com/adefirmansyah123/MySkins/blob/main/louyi_drawing.zip?raw=true");
		_ADDGRIDVIEW("roger cybrog", "https://static.wikia.nocookie.net/mobile-legends/images/a/aa/Cyborg_Werewolf.jpg/revision/latest?cb=20210131042116", "https://github.com/adefirmansyah123/MySkins/blob/main/roger_cybrog.zip?raw=true");
		_ADDGRIDVIEW("Ling spesial", "https://static.wikia.nocookie.net/mobile-legends/images/5/52/Cosmo_Guard.jpg/revision/latest?cb=20210127094038", "https://github.com/gameoverMM/ling-special/blob/main/assets.zip?raw=true");
		_ADDGRIDVIEW("claude blazing", "https://static.wikia.nocookie.net/mobile-legends/images/2/2f/Blazing_Trace_wall.jpg/revision/latest?cb=20201126072839", "https://github.com/gameoverMM/cloud-blazing/blob/main/assets.zip?raw=true");
		_ADDGRIDVIEW("moskov epic", "https://static.wikia.nocookie.net/mobile-legends/images/1/1d/Twilight_Dragon.jpg/revision/latest?cb=20200427032436", "https://github.com/gameoverMM/moskov-epic/blob/main/assets.zip?raw=true");
		_ADDGRIDVIEW("Paquito normal", "https://static.wikia.nocookie.net/mobile-legends/images/c/cf/Death_Blow.jpg/revision/latest?cb=20210129043329", "https://github.com/gameoverMM/paquito-skin/blob/main/assets.zip?raw=true");
	}
	
	
	public void _beckup () {
		new DownloadTask().execute("https://github.com/whoami789/Fighter/blob/main/booster.zip?raw=true");
		_ADDGRIDVIEW("Chou Backup", "https://static.wikia.nocookie.net/mobile-legends/images/d/d7/Kung-Fu_Boy.jpg/revision/latest?cb=20180824202820", "https://github.com/Zlxs04/Backups/blob/master/ChouBackup.zip?raw=true");
		_ADDGRIDVIEW("Paquito backup", "https://static.wikia.nocookie.net/mobile-legends/images/3/3c/Heavenly_Fist.jpg/revision/latest?cb=20201224073004", "https://github.com/Zlxs04/Backups/blob/master/PaquitoBackup.zip?raw=true");
		_ADDGRIDVIEW("karmila backup", "https://static.wikia.nocookie.net/mobile-legends/images/a/af/Shadow_of_Twilight.jpg/revision/latest?cb=20200922023300", "https://github.com/adefirmansyah123/beckupmlbb/blob/main/KARMILA.zip?raw=true");
		_ADDGRIDVIEW("cecilion backup", "https://static.wikia.nocookie.net/mobile-legends/images/1/1b/Embrace_of_Night.jpg/revision/latest?cb=20200103094400", "https://github.com/adefirmansyah123/beckupmlbb/blob/main/cecilion.zip?raw=true");
		_ADDGRIDVIEW("gusion beckup", "https://static.wikia.nocookie.net/mobile-legends/images/9/90/Holy_Blade.jpg/revision/latest?cb=20200922023903", "https://github.com/adefirmansyah123/beckupmlbb/blob/main/gs.zip?raw=true");
		_ADDGRIDVIEW("khaleed backup", "https://static.wikia.nocookie.net/mobile-legends/images/3/3c/Desert_Scimitar.jpg/revision/latest?cb=20200912100057", "https://github.com/adefirmansyah123/beckupmlbb/blob/main/kaled.zip?raw=true");
		_ADDGRIDVIEW("kufra bcakup", "https://static.wikia.nocookie.net/mobile-legends/images/9/91/Desert_Tyrant.jpg/revision/latest?cb=20200922055648", "https://github.com/adefirmansyah123/beckupmlbb/blob/main/kufra.zip?raw=true");
		_ADDGRIDVIEW("louyi backup", "https://static.wikia.nocookie.net/mobile-legends/images/e/e9/Yin-Yang_Geomancer.jpg/revision/latest?cb=20200912100336", "https://github.com/adefirmansyah123/beckupmlbb/blob/main/louyi.zip?raw=true");
		_ADDGRIDVIEW("pharsa back up", "https://static.wikia.nocookie.net/mobile-legends/images/1/16/Wings_of_Vengeance.jpg/revision/latest?cb=20180406195617", "https://github.com/adefirmansyah123/beckupmlbb/blob/main/pharsa.zip?raw=true");
		_ADDGRIDVIEW("roger backup", "https://static.wikia.nocookie.net/mobile-legends/images/0/0b/Dire_Wolf_Hunter.jpg/revision/latest?cb=20180705182702", "https://github.com/adefirmansyah123/beckupmlbb/blob/main/roger.zip?raw=true");
		_ADDGRIDVIEW("dyrroth backup", "", "https://github.com/whoami789/Fighter/blob/main/abc%20Dyrroth%20Backup.zip?raw=true");
		_ADDGRIDVIEW("Hilda backup", "", "https://github.com/whoami789/Fighter/blob/main/abc%20Hilda%20backup.zip?raw=true");
		_ADDGRIDVIEW("Jawhead backup", "", "https://github.com/whoami789/Fighter/blob/main/abc%20Jawhead%20backup.zip?raw=true");
		_ADDGRIDVIEW("lapu lapu backup", "", "https://github.com/whoami789/Fighter/blob/main/abc%20Lapu%20Lapu.zip?raw=true");
		_ADDGRIDVIEW("leomord backup", "", "https://github.com/whoami789/Fighter/blob/main/abc%20Leomord.zip?raw=true");
		_ADDGRIDVIEW("alpha backup", "", "https://github.com/whoami789/Fighter/blob/main/abc%20alpha.zip?raw=true");
		_ADDGRIDVIEW("badang backup", "", "https://github.com/whoami789/Fighter/blob/main/abc%20badang.zip?raw=true");
		_ADDGRIDVIEW("martis backup", "", "https://github.com/whoami789/Fighter/blob/main/abc%20martis.zip?raw=true");
		_ADDGRIDVIEW("masha backup", "", "https://github.com/whoami789/Fighter/blob/main/abc%20masha.zip?raw=true");
		_ADDGRIDVIEW("silvanna backup", "", "https://github.com/whoami789/Fighter/blob/main/abc%20silvana.zip?raw=true");
		_ADDGRIDVIEW("sun backup", "", "https://github.com/whoami789/Fighter/blob/main/abc%20sun.zip?raw=true");
		_ADDGRIDVIEW("ruby backup", "", "https://github.com/whoami789/Fighter/blob/main/ruby%20backup.zip?raw=true");
		_ADDGRIDVIEW("ruby elite", "", "https://github.com/whoami789/Fighter/blob/main/ruby%20elite%201.zip?raw=true");
		_ADDGRIDVIEW("ruby epic", "", "https://github.com/whoami789/Fighter/blob/main/ruby%20epic.zip?raw=true");
		_ADDGRIDVIEW("xbrog x brog backup", "", "https://github.com/whoami789/Fighter/blob/main/abc%20x.borg.zip?raw=true");
		_ADDGRIDVIEW("guinivere backup", "", "https://github.com/whoami789/Fighter/blob/main/guin%20backup.zip?raw=true");
		_ADDGRIDVIEW("terizla backup", "", "https://github.com/whoami789/Fighter/blob/main/abc%20terizla.zip?raw=true");
		_ADDGRIDVIEW("yu Zhong backup", "", "https://github.com/whoami789/Fighter/blob/main/yu%20zhong%20backup.zip?raw=true");
	}
	
	
	public void _PROSES_DIALOG () {
		PROSESS_DIALOG = new ProgressDialog(LayoutMenuActivity.this);
		PROSESS_DIALOG.setMessage("Loading . . .");
		PROSESS_DIALOG.setMax((int)100);
		PROSESS_DIALOG.setCancelable(true);
		PROSESS_DIALOG.setProgressStyle(ProgressDialog.STYLE_SPINNER);
		PROSESS_DIALOG.show();
		time2 = new TimerTask() {
			@Override
			public void run() {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						PROSESS_DIALOG.dismiss();
					}
				});
			}
		};
		_timer.schedule(time2, (int)(1000));
	}
	
	
	public void _FLOATING () {
		_reCall();
		
	}
	private WindowManager windowManager;
	
	private WindowManager.LayoutParams layoutParams;
	
	private View displayView;
	
	private void showFloatingWindow() {
		
		LayoutInflater layoutInflater = LayoutInflater.from(this);
		
		displayView = layoutInflater.inflate(R.layout.floating, null); displayView.setOnTouchListener(new FloatingOnTouchListener());
		
		final LinearLayout line1 = displayView.findViewById(R.id.linear1);
		final LinearLayout line2 = displayView.findViewById(R.id.linear2);
		final Switch sw1 = displayView.findViewById(R.id.switch1);
		final Switch sw2 = displayView.findViewById(R.id.switch2);
		final Switch sw3 = displayView.findViewById(R.id.switch3);
		final Switch sw4 = displayView.findViewById(R.id.switch4);
		final Switch sw5 = displayView.findViewById(R.id.switch5);
		line2.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View _view) {
								closes();
						}
				});
		line1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)3, 0xFF000000, 0xFFFFFFFF));
		line2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)3, 0xFF000000, 0xFFFFEB3B));
		sw1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)3, 0xFF000000, 0xFFFFFFFF));
		sw2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)3, 0xFF000000, 0xFFFFFFFF));
		sw3.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)3, 0xFF000000, 0xFFFFFFFF));
		sw4.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)3, 0xFF000000, 0xFFFFFFFF));
		sw5.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)3, 0xFF000000, 0xFFFFFFFF));
		
		windowManager.addView(displayView, layoutParams);
	}
	
	private class FloatingOnTouchListener implements View.OnTouchListener { 
		private int x;
		private int y;
		
		@Override public boolean onTouch(View view, MotionEvent event) {
			
			switch (event.getAction()) { 
				case MotionEvent.ACTION_DOWN: 
				x = (int) event.getRawX(); 
				y = (int) event.getRawY(); 
				break;
				
				case MotionEvent.ACTION_MOVE: int nowX = (int) event.getRawX(); 
				int nowY = (int) event.getRawY(); 
				int movedX = nowX - x; 
				int movedY = nowY - y; 
				x = nowX; y = nowY; 
				layoutParams.x = layoutParams.x + movedX; 
				layoutParams.y = layoutParams.y + movedY; windowManager.updateViewLayout(view, layoutParams); 
				break; 
				default: 
				break; 
			}
			 return true;
			 }
		 }
	
	public void closes(){
		try{
			windowManager.removeView(displayView);
		}
		catch(Exception e){
			        }
		    }
	private void _reCall(){
	}
	
	
	public class Recyclerview1Adapter extends RecyclerView.Adapter<Recyclerview1Adapter.ViewHolder> {
		ArrayList<HashMap<String, Object>> _data;
		public Recyclerview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _v = _inflater.inflate(R.layout.view, null);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final LinearLayout linear3 = (LinearLayout) _view.findViewById(R.id.linear3);
			final LinearLayout linear1 = (LinearLayout) _view.findViewById(R.id.linear1);
			final TextView textview1 = (TextView) _view.findViewById(R.id.textview1);
			final ImageView imageview1 = (ImageView) _view.findViewById(R.id.imageview1);
			
			Glide.with(getApplicationContext()).load(Uri.parse(MAP.get((int)_position).get("IMG").toString())).into(imageview1);
			if (false) {
				linear1.setOnTouchListener(new View.OnTouchListener() {
					@Override
					public boolean onTouch(View v, MotionEvent event) {
						switch (event.getAction()){
							case MotionEvent.ACTION_DOWN:{
								ObjectAnimator scaleX = new ObjectAnimator();
								scaleX.setTarget(linear1);
								scaleX.setPropertyName("scaleX");
								scaleX.setFloatValues(0.9f);
								scaleX.setDuration(100);
								scaleX.start();
								
								ObjectAnimator scaleY = new ObjectAnimator();
								scaleY.setTarget(linear1);
								scaleY.setPropertyName("scaleY");
								scaleY.setFloatValues(0.9f);
								scaleY.setDuration(100);
								scaleY.start();
								break;
							}
							case MotionEvent.ACTION_UP:{
								
								ObjectAnimator scaleX = new ObjectAnimator();
								scaleX.setTarget(linear1);
								scaleX.setPropertyName("scaleX");
								scaleX.setFloatValues((float)1);
								scaleX.setDuration(100);
								scaleX.start();
								
								ObjectAnimator scaleY = new ObjectAnimator();
								scaleY.setTarget(linear1);
								scaleY.setPropertyName("scaleY");
								scaleY.setFloatValues((float)1);
								scaleY.setDuration(100);
								scaleY.start();
								
								break;
							}
						}
						return false;
					}
				});
			}
			android.graphics.drawable.GradientDrawable gb = new android.graphics.drawable.GradientDrawable();
			gb.setColors(new int[]{ 0xFF1B1E23, 0xFF000000 });
			gb.setCornerRadii(new float[] { (float)0, (float)0, (float)0, (float)0, (float)20, (float)20, (float)20, (float)20 });
			gb.setStroke(4,0xFFFFFFFF);
			textview1.setBackground(gb);
			android.graphics.drawable.GradientDrawable gbr = new android.graphics.drawable.GradientDrawable();
			gbr.setColors(new int[]{ 0xFF1B1E23, 0xFF000000 });
			gbr.setCornerRadii(new float[] { (float)0, (float)0, (float)0, (float)0, (float)20, (float)20, (float)20, (float)20 });
			gbr.setStroke(4,0xFFFFFFFF);
			linear3.setBackground(gb);
			textview1.setText(MAP.get((int)_position).get("NAMA").toString());
			imageview1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					Injector.setTitle("🔰".concat(MAP.get((int)_position).get("NAMA").toString()));
					Injector.setIcon(R.drawable.kuriyama);
					Injector.setMessage("Are You Sure ?");
					Injector.setPositiveButton("Oke", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							new DownloadTask().execute(MAP.get((int)_position).get("URL").toString());
						}
					});
					Injector.setNegativeButton("Cancle", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							
						}
					});
					Injector.create().show();
				}
			});
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder{
			public ViewHolder(View v){
				super(v);
			}
		}
		
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
