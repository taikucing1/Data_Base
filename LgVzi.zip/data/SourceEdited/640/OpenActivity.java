package lotus.volt;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import com.google.android.material.appbar.AppBarLayout;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Button;
import android.widget.ImageView;
import android.content.Intent;
import android.net.Uri;
import java.util.Timer;
import java.util.TimerTask;
import android.view.View;
import com.bumptech.glide.Glide;
import com.startapp.sdk.*;
import com.kaopiz.kprogresshud.*;
import com.shashank.sony.fancytoastlib.*;
import com.azoft.carousellayoutmanager.*;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.DialogFragment;
import androidx.core.content.ContextCompat;
import androidx.core.app.ActivityCompat;
import android.Manifest;
import android.content.pm.PackageManager;


public class OpenActivity extends  AppCompatActivity  { 
	
	private Timer _timer = new Timer();
	
	private Toolbar _toolbar;
	private AppBarLayout _app_bar;
	private CoordinatorLayout _coordinator;
	private double size = 0;
	private double sumCount = 0;
	private String path = "";
	private String path1 = "";
	private String result = "";
	private String filename = "";
	
	private LinearLayout linear1;
	private LinearLayout linear3;
	private TextView textview1;
	private LinearLayout linear2;
	private Button button1;
	private ImageView imageview1;
	
	private Intent EMOT = new Intent();
	private RequestNetwork net;
	private RequestNetwork.RequestListener _net_request_listener;
	private Intent injector = new Intent();
	private TimerTask time2;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.open);
		initialize(_savedInstanceState);
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
		}
		else {
			initializeLogic();
		}
	}
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		_app_bar = (AppBarLayout) findViewById(R.id._app_bar);
		_coordinator = (CoordinatorLayout) findViewById(R.id._coordinator);
		_toolbar = (Toolbar) findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		textview1 = (TextView) findViewById(R.id.textview1);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		button1 = (Button) findViewById(R.id.button1);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		net = new RequestNetwork(this);
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				new DownloadTask().execute(textview1.getText().toString());
			}
		});
		
		_net_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
	}
	
	private void initializeLogic() {
		Glide.with(getApplicationContext()).load(Uri.parse(getIntent().getStringExtra("A"))).into(imageview1);
		textview1.setText(getIntent().getStringExtra("B"));
		_ATPHRoundImage(20, 5, linear2, imageview1);
		linear3.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)2, 0xFF000000, 0xFFEEEEEE));
		setTitle("Subscribe Youtube Lotus Volt Chanel");
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	//Injector
	public void Injector () {
		 //injector
		
	}
	
	private class DownloadTask extends AsyncTask<String, Integer, String> {
		KProgressHUD khud;
		
		
		 @Override
		protected void onPreExecute() {
			 
			super.onPreExecute();
			khud = new KProgressHUD(OpenActivity.this).setStyle(KProgressHUD.Style.PIE_DETERMINATE).setLabel("Lv Injector")
			.setMaxProgress(100);
			FancyToast.makeText(OpenActivity.this, "Downloading", FancyToast.LENGTH_LONG, FancyToast.INFO, false).show();
			khud.show();
			
		}
		protected String doInBackground(String... address) {
			try {
				filename= URLUtil.guessFileName(address[0], null, null);
				int resCode = -1;
				java.io.InputStream in = null;
				java.net.URL url = new java.net.URL(address[0]);
				java.net.URLConnection urlConn = url.openConnection();
				if (!(urlConn instanceof java.net.HttpURLConnection)) {
					throw new java.io.IOException("URL is not an Http URL"); }
				java.net.HttpURLConnection httpConn = (java.net.HttpURLConnection) urlConn; httpConn.setAllowUserInteraction(false); httpConn.setInstanceFollowRedirects(true); httpConn.setRequestMethod("GET"); httpConn.connect();
				resCode = httpConn.getResponseCode();
				if (resCode == java.net.HttpURLConnection.HTTP_OK) {
					in = httpConn.getInputStream();
					size = httpConn.getContentLength();
					
				} else { result = "There was an error"; }
				path = FileUtil.getExternalStorageDir().concat("/.data/".concat(filename));
				FileUtil.writeFile(path, "");
				path1 = FileUtil.getExternalStorageDir().concat("/android/data/com.mobile.legends/files/dragon2017/assets/");
				java.io.File file = new java.io.File(path);
				
				java.io.OutputStream output = new java.io.FileOutputStream(file);
				try {
					int bytesRead;
					sumCount = 0;
					byte[] buffer = new byte[1024];
					while ((bytesRead = in.read(buffer)) != -1) {
						output.write(buffer, 0, bytesRead);
						sumCount += bytesRead;
						if (size > 0) {
							publishProgress((int)Math.round(sumCount*100 / size));
						}
					}
				} finally {
					output.close();
				}
				result = filename + " saved";
				in.close();
			} catch (java.net.MalformedURLException e) {
				result = e.getMessage();
			} catch (java.io.IOException e) {
				result = e.getMessage();
			} catch (Exception e) {
				result = e.toString();
			}
			return result;
			
		}
		protected void onProgressUpdate(Integer... values) {
			khud.setProgress(values[values.length - 1]);
			khud.setDetailsLabel(String.valueOf((long)(values[values.length - 1])).concat("%"));
		}
		protected void onPostExecute(String s){
			
			showMessage(s);
			khud.dismiss();
			
			FancyToast.makeText(OpenActivity.this, "Succesfull", FancyToast.LENGTH_LONG, FancyToast.SUCCESS, false).show();
			time2 = new TimerTask() {
					@Override
					public void run() {
							runOnUiThread(new Runnable() {
									@Override
									public void run() {
											FileUtil.deleteFile(path);
									}
							});
					}
			};
			final String _fileZip=(path);
			final String _destDir=(path1);
							
							try
							{
									java.io.File outdir = new java.io.File(_destDir);
									java.util.zip.ZipInputStream zin = new java.util.zip.ZipInputStream(new java.io.FileInputStream(_fileZip));
									java.util.zip.ZipEntry entry;
									String name, dir;
									while ((entry = zin.getNextEntry()) != null)
									{
											name = entry.getName();
											if(entry.isDirectory())
											{
													mkdirs(outdir, name);
													continue;
											}
											
											/* this part is necessary because file entry can come before
* directory entry where is file located
* i.e.:
* /foo/foo.txt
* /foo/
*/
											
											dir = dirpart(name);
											if(dir != null)
											mkdirs(outdir, dir);
											
											extractFile(zin, outdir, name);
									}
									zin.close();
							}
							catch (java.io.IOException e)
							{
									e.printStackTrace();
							}
							
							
					}
					private  void extractFile(java.util.zip.ZipInputStream in, java.io.File outdir, String name) throws java.io.IOException
					{
							byte[] buffer = new byte[4096];
							java.io.BufferedOutputStream out = new java.io.BufferedOutputStream(new java.io.FileOutputStream(new java.io.File(outdir, name)));
							int count = -1;
							while ((count = in.read(buffer)) != -1)
							out.write(buffer, 0, count);
							out.close();
					}
					
					private void mkdirs(java.io.File outdir, String path)
					{
							java.io.File d = new java.io.File(outdir, path);
							if(!d.exists())
							d.mkdirs();
					}
					
					private String dirpart(String name)
					{
							int s = name.lastIndexOf(java.io.File.separatorChar);
							return s == -1 ? null : name.substring(0, s);
						
			
		}
		
	}
	
	@Override
	public void onBackPressed() {
		EMOT.setClass(getApplicationContext(), LayoutMenuActivity.class);
		startActivity(EMOT);
		finish();
	}
	public void _ATPHRoundImage (final double _radius, final double _shadow, final View _view, final ImageView _imageview) {
		androidx.cardview.widget.CardView cv = new androidx.cardview.widget.CardView(this);
		
		LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
		
		lp.setMargins(12,12,12,12);
		
		cv.setLayoutParams(lp);
		
		cv.setCardBackgroundColor(Color.WHITE);
		
		cv.setRadius((float)_radius);
		
		cv.setCardElevation((float)_shadow);
		
		cv.setMaxCardElevation(5);
		
		cv.setPreventCornerOverlap(true);
		
		((LinearLayout)_view).removeView(_imageview);
		
		((LinearLayout)_view).addView(cv);
		
		cv.addView(_imageview);
	
	
}


@Deprecated
public void showMessage(String _s) {
	Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
}

@Deprecated
public int getLocationX(View _v) {
	int _location[] = new int[2];
	_v.getLocationInWindow(_location);
	return _location[0];
}

@Deprecated
public int getLocationY(View _v) {
	int _location[] = new int[2];
	_v.getLocationInWindow(_location);
	return _location[1];
}

@Deprecated
public int getRandom(int _min, int _max) {
	Random random = new Random();
	return random.nextInt(_max - _min + 1) + _min;
}

@Deprecated
public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
	ArrayList<Double> _result = new ArrayList<Double>();
	SparseBooleanArray _arr = _list.getCheckedItemPositions();
	for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
		if (_arr.valueAt(_iIdx))
		_result.add((double)_arr.keyAt(_iIdx));
	}
	return _result;
}

@Deprecated
public float getDip(int _input){
	return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
}

@Deprecated
public int getDisplayWidthPixels(){
	return getResources().getDisplayMetrics().widthPixels;
}

@Deprecated
public int getDisplayHeightPixels(){
	return getResources().getDisplayMetrics().heightPixels;
}

}
